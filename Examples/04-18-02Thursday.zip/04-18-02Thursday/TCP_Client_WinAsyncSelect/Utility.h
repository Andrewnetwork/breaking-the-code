// Utility.h
// Miscellaneous utility functions

#if !defined(_UTILITY_H_)
#define _UTILITY_H_

#include <afxwin.h>

void     SetMouseCursorAt (CPoint  pt, HWND  hWnd);

CString  GetLeftWord     (CString s);
void     RemoveLeftWord  (CString& s);
void     GetNthWord      (CString& s, int n);

int      TaxiDistBtwnPts (CPoint pt1, CPoint pt2);

#endif