// Permutation.h
// Andrew Ribeiro 
// February 23, 2011

#include <vector> 
#include <iostream>
#include <string>
using namespace std; 

class Permutation 
{
private:
	vector<unsigned int> counters;
	vector<char> * alphabet; 
	unsigned int alphabetSize;


public:
	
	// #Constructors 
	Permutation(unsigned int length, vector<char> * alphabet, unsigned int alphabetSize);

	// #Essentials
	const Permutation & operator++();
	string getPemutationString();

	// #Utility 
	unsigned int characterPositionInAlphabet( vector< char > * alphabet,  char ch );
	char characterAtPositionInAlphabet( vector< char > *alphabet, unsigned int pos );
	void initCounters( unsigned int value );
	void incrementCounters(unsigned int incrementAmt);

	// #Accessors 
	vector< unsigned  int > & getCountersReference() { return counters; }
	vector< char > * getAlphabetReference() { return alphabet; }
	unsigned int size(){ return counters.size(); }

	// #Overloads
	unsigned int & operator[]( unsigned int index );

	// #Friends 
	friend ostream& operator<<(ostream& output, Permutation p);
};