#include <iostream>
#include <Windows.h>
#include "ReceiveFile.h"
#include <string>

using namespace std; 

int main( int argc, char * args )
{
	const int iReqWinsockVer = 2;   // Minimum winsock version required

WSADATA wsaData;

	if (WSAStartup(MAKEWORD(iReqWinsockVer,0), &wsaData)==0)
	{
		// Check if major version is at least iReqWinsockVer
		if (LOBYTE(wsaData.wVersion) >= iReqWinsockVer)
		{
			/* ------- Call winsock functions here ------- */
			cout<<"This computer has Winsock 2!"<<endl;

			SOCKET hSocket;

			hSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
			if (hSocket != INVALID_SOCKET)
			{
				cout<<"Success in creating a socket."<<endl;

				/* This code assumes a socket has been created and its handle
				   is stored in a variable called hSocket */

				sockaddr_in sockAddr;

				sockAddr.sin_family = AF_INET;
				sockAddr.sin_port = htons(2034);
				sockAddr.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");

				// Bind socket to port 80
				if (connect(hSocket, (sockaddr*)(&sockAddr), sizeof(sockAddr)) == 0)
				{
					cout<<"Connected to server!!"<<endl;

					while( true )
					{
						ReceiveFile prgm( hSocket );

						cout<<"Got file: "<<prgm.getFileWithName();
					}

				}
				else
				{
					//Cannot connect to socket.
					cout<<"Cannot connect to socket"<<endl;
				}
		
			}
			else
			{
				// error handling code
				cout<<"Failure in creating a socket."<<endl;
			}
		}
		else
		{
			// Required version not available
			cout<<"Did not work!"<<endl;
		}

		// Cleanup winsock
		if (WSACleanup()!=0)
		{
			// cleanup failed
		}
	}
	else
	{
		//  startup failed
	}
	system("pause");
	return 0;
}