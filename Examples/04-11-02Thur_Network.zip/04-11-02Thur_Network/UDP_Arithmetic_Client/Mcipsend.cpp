//******************************************
// int_UDP_Client_2
//   Sends an int arithmetic expression to server 
//   Server returns result
//******************************************

#include <windows.h>
#include <iostream.h>
#include <winsock.h>

#define NO_FLAGS_SET  0

int main(VOID)
{
  WSADATA       wsaData;
  SOCKET        hSocket;     // handle to socket
  SOCKADDR_IN   SockAddr;    // Holds address of target machine, port also 

  // 1. Initialize WSA: Window Socket A'PI 
  int   status;
  status = WSAStartup (
             MAKEWORD(1, 1),// version
             &wsaData       // Info about winsocket implementation  
                      );
  if (status != 0) {cerr << "ERROR in WSAStartup()\n"; return 1;} 

  // 2. Create a socket. Specifies protocol: UDP or TCP
  hSocket = socket (         // Returns a 'handle' to the socket info
             AF_INET,    // Internet family
             SOCK_DGRAM, // SOCK_DGRAM = UDP,
             0           //
                   );
  if (hSocket == INVALID_SOCKET) {cerr << "ERROR: socket unsuccessful\n"; return 1;}

  cout << "\nUDP Client: Sends int arithmetic expressions to server for evaluation ...";
  // 3. Initialize 'sockaddr_in' struct for server. 
  SockAddr.sin_family       = AF_INET;

  // - Get IP address of server
  char Server_IP_Addr[40];
  cout << "\nEnter IP addr (0 = local host) of server ? ";
  cin.getline (Server_IP_Addr, 40);
  if ( strcmp (Server_IP_Addr,"0") == 0)
    strcpy (Server_IP_Addr,"127.0.0.1");
  unsigned long ServerAddr  = inet_addr(Server_IP_Addr);
  memcpy(&SockAddr.sin_addr, &ServerAddr, sizeof(ServerAddr));

  u_short  port;
  cout << "Enter port # for server ? "; cin >> port;
  SockAddr.sin_port         = htons(port);     // Port # of server

  // 4. (a) Send message and (b) receive result
  struct SExpr {
    int   x;
    char  op;
    int   y;
    int   result;
  };
  struct SExpr Expr;
  
  int  nBytesSent;
  int  nBytesRecvd;
  for ( ; ; )
  {
    // (a) Compose message
    char  resp;
    cout << "\nSend another expression (y/n) ? ";
    cin >> resp;
    if (toupper(resp) == 'N') break;
    cout << "                    x = ? "; cin >> Expr.x;
    cout << "  operation (+,-,*,/) = ? "; cin >> Expr.op;
    cout << "                    y = ? "; cin >> Expr.y;

    // (b) Send message
    nBytesSent = sendto (     // returns number bytes sent
            hSocket,                // Handle to socket
            (char *)&Expr,
            sizeof Expr,
            NO_FLAGS_SET,           // flags that affect behavior of sendto()
            (LPSOCKADDR) &SockAddr, // Server IP and port #
            sizeof(SockAddr)
                        );
    if (nBytesSent != (int)sizeof(Expr) )
    {
      cerr << "ERROR: sendto unsuccessful\n";
      closesocket (hSocket); WSACleanup(); return 1;
    }

    // (c) Receive and display result
    nBytesRecvd = recvfrom (
            hSocket,
            (char *)&Expr,
            sizeof Expr,
            NO_FLAGS_SET,
            NULL,
            NULL
                           );
    cout << "  The result is: " << Expr.result << "\n";
  } 
  shutdown(hSocket,2);
  WSACleanup();
  return 0;
}
