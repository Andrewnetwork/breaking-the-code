// CommandLinePrinter.cpp
// Andrew Ribeiro 
// February 23, 2010

#include <iostream>
using namespace std; 


int main( int argc, const char * args[] ) 
{
	cout<<"This is a program that prints out the command line arguments provided."<<endl<<endl;

	for( unsigned int i = 0; i < argc; i++ )
	{
		cout<<"Arg( "<<i<<" ): "<<args[i]<<endl;
	}

	int exitCode; 

	cout<<"Enter an integer exit code: ";
	cin>>exitCode; 

	return exitCode; 
}