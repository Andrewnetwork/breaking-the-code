// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers



// TODO: reference additional headers your program requires here

#include <windows.h>
#include <conio.h>
#include <iostream>
#include <string>
#include <winsock.h>
#include "SimpleClientSocket.h"
#include "SimpleServerSocket.h"
#include "SimpleSocket.h"
#include "SocketCommunicator.h"