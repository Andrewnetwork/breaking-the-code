// App.h

#if !defined(_APP_H_)
#define _APP_H_

class CApp  
{
private:
	CString mStr;

public:

	CApp();
	virtual ~CApp();
	void Do();

};

#endif 
