#include <iostream>
using namespace std; 


void main()
{
	cout<<"Enter an integer and I will tell you if it is odd!"<<endl<<endl;

	while( true )
	{
		int i; 

		cout<<"Number: ";
		cin >> i; 

		if( i % 2 == 0 )
		{
			cout<<i<<" is even!"<<endl;
		}
		else
		{
			cout<<i<<" is odd!"<<endl;
		}
	}
}