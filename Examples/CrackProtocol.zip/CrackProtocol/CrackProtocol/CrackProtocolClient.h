// CrackProtocolClient.h
// Andrew Ribeiro
// April 10, 2011

#pragma once 

#include <Windows.h>
#include <string> 
#include <vector>

#include "..\GlobalHeaders\SimpleSocketsLibrary\SocketCommunicator.h"
#include "..\GlobalHeaders\CrackProtocolConstants.h"

using namespace AndrewRibeiro; 
using namespace std; 

struct CodeCrackingThreadArgs
{
	string serverIP;
	string serverPort;
	bool * exitFlag;
	string verificationPort;
	vector<char> alphabet;
	unsigned int alphaSize;

	CodeCrackingThreadArgs( string ip, string port, bool * eFlag, string vPort, vector<char> alpha, unsigned int alphSize)
	{
		serverIP            = ip;
		serverPort          = port;
		exitFlag            = eFlag;
		verificationPort    = vPort;
		alphabet            = alpha;
		alphaSize           = alphSize;
	}

};

class CrackProtocolClient
{
public:

	CrackProtocolClient( SOCKET activeConnection );

	// ## Protocol Functions ## 

	bool getProcessStatus();
	string  requestInformation();
	bool startProcess( string name, string email, string verificationArchPath );
	void rangeComplete( string crackedCode );
	pair<vector<unsigned char>, vector<unsigned char> > getRange();
	string getVerificationArchive();
	void invalidOperation(string errorMessage);



private:
	SOCKET connection;
	SocketCommunicator * connectionCom;

	string getFileContents( string filePath );

	bool makeDirectory( string name, string bin );
	bool unzipFile( string name );

};