// CrackProtocolConstants.h
// Andrew Ribeiro 
// April 10, 2010

#pragma once

#include <string>
using std::string;


const string KEY_START_PROCESS = "SP";
const string KEY_GET_PROCESS_STATUS = "PS";
const string KEY_RANGE_COMPLETE = "RC";
const string KEY_REQUEST_INFO = "RI";
const string KEY_GET_RANGE = "GR";
const string KEY_GET_VERIFICATION_ARCHIVE = "GA";

const char BLANK_CHAR = 125;



// Server -> Client Keywords

const string KEY_OK = "OK";
const string KEY_NO = "NO";



// Server <-> Client
const string KEY_UNSUPPORTED_OP = "UO";

