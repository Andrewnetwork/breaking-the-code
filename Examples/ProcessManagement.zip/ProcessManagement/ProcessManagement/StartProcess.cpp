// StartProcess.cpp
// Modified by: Andrew Ribeiro
//
// Credit: Jones Assembler and w32 mfc

#include <windows.h>
#include <iostream>
#include <string>
using namespace std;

int main(void)
{
  STARTUPINFO         startUpInfo;
  PROCESS_INFORMATION procInfo;
  BOOL                success;
  char                appName[256];
  DWORD               processExitCode; 
  LPDWORD			  ptrProccessExitCode = &processExitCode; 



  // 1. Get the name of the child process to run
  
  strcpy (appName, "CommandLinePrinter.exe\0" );

  cout << "\nThis program starts a program named '"<<appName<<"'";
  cout << "\n  The exe file must be in the current directory.";



  // 2. Retrieve the STARTUPINFOR structure for current process
  GetStartupInfo(&startUpInfo);

  // 2.5 Get the command line arguments. 
  unsigned int nArgs = 0; 
  string argsOut = "";

  cout<<"\nHow many arguments would you like to provide( positive integer ): ";
  cin>>nArgs; 

  for( int i = 0; i < nArgs; i++ )
  {
	  string argument = ""; 

	  cout<<"\nArgument( "<<i<<" ): ";
	  cin>>argument; 

	  argsOut += argument + " ";
  }

  // 3. Create the child process
  success = CreateProcess(
                  appName, // or NULL    // app. name
				  (LPSTR)argsOut.c_str(),    // c:\ ... // command line
                  NULL,   // security
                  NULL,   // thread security
                  FALSE,  // do not inherit handles of parent process
                  CREATE_NEW_CONSOLE, // various constants
                  NULL,      // points to array of string containing environment variables
                  NULL,      // Starting drive and directory for the process
                  &startUpInfo, // appearance ifno
                  &procInfo     // return info for process
                          );
  if ( !success )
  {
    cout << "Error creating process: " 
         << GetLastError() << endl;
    return 1;
  }

  // 4. Wait for the child process to complete
  cout << "\nWait for child process to complete . . . ";

  // Wait any amount of time until the process has completed. 
  WaitForSingleObject( procInfo.hProcess, INFINITE );

  // Get the process exit code. 
  GetExitCodeProcess( procInfo.hProcess, ptrProccessExitCode );

  cout << "\nProcess exit code: "<<processExitCode<<endl
	   << "\nComplete. Now exit."<<endl;

  system("pause");

  return 0;
}
