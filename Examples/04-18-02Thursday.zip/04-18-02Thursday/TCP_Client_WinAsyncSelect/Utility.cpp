// Utility.cpp
// Miscellaneous utility functions

#include "Utility.h"

/* - - - - - - - - - - - - - - - - - - - - - - - - 
void     SetMouseCursorAt (CPoint  pt, HWND  hWnd);

CString  GetLeftWord     (CString s);
void     RemoveLeftWord  (CString& s);
void     GetNthWord      (CString& s, int n);

int      TaxiDistBtwnPts (CPoint pt1, CPoint pt2);
- - - - - - - - - - - - - - - - - - - - - - - - - - */

void SetMouseCursorAt (CPoint  pt, HWND  hWnd)
{
  ClientToScreen (hWnd, &pt);
  SetCursorPos (pt.x, pt.y);
  return;
}

CString GetLeftWord (CString s)
{
  s.TrimLeft();
  s.TrimRight();
  
  int i = s.Find(" ");
  if (i < 0) return s;

  CString word = s.Left(i);
  word.TrimLeft();
  return word;
}

void RemoveLeftWord(CString& s)
{
  // if s has no word, unchanged
  // if s has 1 word, removes it to ""
  s.TrimLeft();
  s.TrimRight();

  // Case 0: nothing in string
  if (s.GetLength() == 0) return;

  int i = s.Find(" ");

  // Case 1; one word left, it is removed 
  if (i < 0)
  {
    s.Empty();
    return;
  }
  
  // Case 2: More than one word
  CString remain;
  remain = s.Right(s.GetLength()-i-1);
  remain.TrimLeft();
  s = remain;
}

void GetNthWord (CString& s, int n)
{
  if (n == 0) return;   // unchanged
  int i;
  for (i = 1; i < n; i++)
      RemoveLeftWord (s);
  
  CString t;
  t = GetLeftWord(s);
  s = t;
}

int TaxiDistBtwnPts (CPoint pt1, CPoint pt2)
{
  return abs(pt1.x - pt2.x) + abs(pt1.y - pt2.y);
}
