/***********************************************************************
*
* Example of using XmlStream class.
*  Author/Modifier: Jaynam Shah, April 4, 2011
* This code is provided "as is", with absolutely no warranty expressed
* or implied. Any use is at your own risk.
************************************************************************/
#include <iostream>
#include <fstream>
#include "xmlwriter.h"

using namespace std;
using namespace	xmlw;

class	XML_Make{
public:
	XML_Make(); // Constructer
	void XML_Write(); // Writing a XML file
};

void XML_Make::XML_Write() 
{
	ofstream	f("C:\\Users\\jaynam\\Desktop\\sample.xml"); // Creating a file
	XmlStream	xml(f);

	xml << prolog() // write XML file declaration
		<< tag("codedata") // root tag
			<< tag("user1") // child tag
				<< tag("name") << chardata() << "Jaynam" << endtag("name") 
				<< tag("code") << chardata() <<"abc32AS" <<endtag("code") 
				<< tag("email") << chardata() << "abc@yahoo.com"<<endtag("email")
			<<endtag("user1")
		<< endtag("codedata"); // End of XML file writer.

	cout << "XML file has been created "<<endl;
	system("pause");
}
