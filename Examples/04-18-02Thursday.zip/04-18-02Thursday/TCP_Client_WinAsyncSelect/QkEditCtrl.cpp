// QkEditCtrl.cpp
#include "QkEditCtrl.h"

CQkEditCtrl::CQkEditCtrl()
{
  hEditWnd   = NULL;
}

CQkEditCtrl::~CQkEditCtrl()
{ 
  Destroy();
}

 void CQkEditCtrl::Create (HWND hWnd, UINT id, CPoint xyPosition, CString Prompt, int Width, int style)
{
  // Step 1. Can only create it once
  if (hEditWnd != NULL)
  {
    SetWindowText (hWnd,"Already created");
    Sleep (250);
    return;    // Already created.
  }
  hParent = hWnd;
  mID = id;

  // Step 2.  Set member properties
  mPosition = xyPosition;
  mPrompt   = Prompt;
  mWidth    = Width;
  mVisible  = FALSE;

  // Step 3. Determine length of prompt
  HDC hDC = GetDC(hWnd);
  CSize sz;
  GetTextExtentPoint32 (hDC, mPrompt, mPrompt.GetLength(), &sz);

  // Step 4: Determine the height of a character
  TEXTMETRIC tm;
  GetTextMetrics (hDC,&tm);

  int BoxHeight = tm.tmHeight + tm.tmExternalLeading + 10;
  ReleaseDC(hWnd,hDC);

  int LeftEdge;
  int TopEdge;

  if (style == 0)
  {
    LeftEdge = mPosition.x + 10 + sz.cx;
    TopEdge  = mPosition.y;
  }
  else
  {
    LeftEdge = mPosition.x;
    TopEdge  = mPosition.y + 20;
  }

  // Step 6: Create the QkEditCtrl
  hEditWnd = CreateWindowEx 
    (
    WS_EX_CLIENTEDGE,
    TEXT("edit"),
    NULL,
    WS_CHILD|WS_BORDER|ES_AUTOHSCROLL, // styles
    LeftEdge,                     // left edge
    TopEdge,                      // top edge
    mWidth,                       // width
    BoxHeight,                      // height
    hWnd,                         // parent window
    (HMENU)mID, // window ID, Most any number will do
    (HINSTANCE)GetWindowLong (hWnd, GWL_HINSTANCE), 
    NULL  // creation parameters
    );
}

HWND CQkEditCtrl::GetHandle()
{
  return hEditWnd;
}

UINT CQkEditCtrl::GetObjectID()
{
  return mID;
}

void CQkEditCtrl::Show (HWND hWnd)
{
  // Step 1: Display prompt
  HDC hDC;
  hDC       = GetDC(hWnd);
  SetBkMode (hDC,TRANSPARENT);
  TextOut   (hDC, mPosition.x, mPosition.y, mPrompt, mPrompt.GetLength() );
  ReleaseDC (hWnd,hDC);

  // Step 2: Show input box
  ShowWindow (hEditWnd, SW_SHOW);
  mVisible = TRUE;
}

void CQkEditCtrl::Hide (HWND hWnd)
{
  ShowWindow (hEditWnd,SW_HIDE);
  mVisible = FALSE;
  InvalidateRect (hWnd,NULL,TRUE);
}

void CQkEditCtrl::GetCString (CString& s, int n)
{
  char  sz[256];
  GetWindowText (hEditWnd, sz, 99);

  CString t;
  t = sz;

  GetNthWord (t,n);
  s = t;
  ::SetFocus(hParent);
}

void CQkEditCtrl::GetInt (long &i, int n)
{
  char  sz[100];
  GetWindowText (hEditWnd, sz, 99);

  CString t;
  t = sz;       // get a cstring

  GetNthWord (t,n); 
  strcpy (sz,t);
  i = atoi(sz);

  ::SetFocus(hParent);
}

void CQkEditCtrl::GetDouble (double& d, int n)
{
  char  sz[100];
  GetWindowText (hEditWnd, sz, 99);

  CString t;
  t = sz;       // get a cstring

  GetNthWord (t,n); 
  strcpy (sz,t);
  d = atof(sz);

  ::SetFocus(hParent);
}

void CQkEditCtrl::GetCharStr (char s[])
{
  GetWindowText (hEditWnd, s, 99);
  ::SetFocus(hParent);
}

void CQkEditCtrl::SetValue(CString s)
{
  SetWindowText (hEditWnd,s);
}

void CQkEditCtrl::ShowPrompt (HDC hDC)
{
  if (mVisible)
  {
    SetBkMode(hDC,TRANSPARENT);
    TextOut(hDC,mPosition.x, mPosition.y, mPrompt, mPrompt.GetLength());
  }
}

void CQkEditCtrl::Destroy ()
{ 
  DeleteObject (hEditWnd);
  hEditWnd  = NULL;
  mVisible = FALSE;
}


