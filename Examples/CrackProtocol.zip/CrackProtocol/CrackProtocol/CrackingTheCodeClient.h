// CrackingTheCodeClient.h
// Andrew Ribeiro
// April 13, 2011

#pragma once 

#include <string>
#include <vector>
#include <Windows.h>

using namespace std;

class CrackingTheCodeClient
{
public:

	CrackingTheCodeClient();

	// ## Use Case Methods ##
	void crackCode();
	void stopCrackingCode();
	void displayInfo();
	void startProcess(string processName, string email, string verificationArchivePath);

private:
	
	HANDLE hVerificationServer;

	// ## Configuration Variables ##
	string serverPort; 
	string serverIP;
	string verificationPort;
	vector< char > alphabet; 
	unsigned int alphabetSize;

	// ## Threading Flags ##
	vector< bool * > codeCrackingExitFlags;

	// ## Threading Methods ##
	HANDLE startNewCodeCrackingThread( bool * exitFlag );
	friend DWORD WINAPI crackCodeThread( LPVOID arg );

	// ## Utility Methods ##

	bool startVerificationServer();
	
};