// SimpleClientSocket.cpp
// Andrew Ribeiro 
// March 4, 2011

#include "Stdafx.h"

namespace AndrewRibeiro
{
	SOCKET SimpleClientSocket::connectToServer( string serverIP, string serverPort )
	{
		string initError = init();

		if( initError.size() == 0 )
		{	
			SockAddr.sin_family       = AF_INET;
			SockAddr.sin_addr.s_addr  = inet_addr( serverIP.c_str() );
			SockAddr.sin_port         = htons( atoi(serverPort.c_str()) );

			// Connecting to server 
			int status = connect (hSocket,(LPSOCKADDR) &SockAddr,sizeof(SockAddr));

			if (status == INVALID_SOCKET)
			{
				cerr<<"Error: connecting to server '"<<serverIP<<"' on port '"<<serverPort<<"'"<<endl;
				cout<<"Connect status: "<<status<<endl;
				return NULL;
			}

			return hSocket;
		}
		else
		{
			cout<<"Error: "<<initError<<endl;
			return NULL;
		}
	}
}