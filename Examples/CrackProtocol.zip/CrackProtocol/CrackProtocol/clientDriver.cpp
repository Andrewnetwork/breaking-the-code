// clientDriver.cpp
// Andrew Ribeiro 
// April 10, 2010



#include "CrackingTheCodeClient.h"
#include <iostream>

using namespace std;

void PushStringOntoBuffer(char *str);

void main()
{
	int choice; 

	CrackingTheCodeClient test;

	while( true )
	{
	    PushStringOntoBuffer("Start cracking, start process, get info, or stop cracking (1,2,3,4)");

		cin>>choice;

		switch(choice)
		{
		case 1:
			test.crackCode();
			break;
		case 2:
			test.startProcess("Andrew's hash","andrewnetwork@gmail.com","t.zip");
			break;
		case 3:
			test.displayInfo();
			break;
		case 4:
			test.stopCrackingCode();
			break;
		default:
			PushStringOntoBuffer("Invalid choice!");
		}

	}

}

