//**************************************
// Project: int UDP_Server_2 
// Server
//   Receives an arithmetic expression from a client
//   Returns the result
//**************************************
// Server:   mciprecv.cpp

#include <windows.h>
#include <iostream.h>
#include <winsock.h>
#include <conio.h>

#define NO_FLAGS_SET 0
#define PORT        (u_short)44965

int main(VOID)
{
  WSADATA     wsaData;
  SOCKET      hSocket;           // Handle to the socket 
  SOCKADDR_IN SockAddr;          // IP address and Port for service

  struct SExpr {
    int   x;
    char  op;
    int   y;
    int   result;
  };

  // 1. Initialize WSA: Window Socket A'PI, the DLL
  int status;
  status = WSAStartup (       
              MAKEWORD(1, 1), // Version # of winsock lib
              &wsaData        // Data about winsock implementation: E.g.:
                              //    Max sockets, Max UDP datagram size, etc
                      );
  if (status != 0) cout << "ERROR in WSAStartup()\n";

  // 2. Create a socket. Essentially, specifies protocol.  
  hSocket = socket (      // Returns a "handle" to the socket, a descriptor
                 AF_INET,    // "addr family" internet 
                 SOCK_DGRAM, // socket type: SOCK_DGRAM = UDP, SOCK_STREAM = TCP
                 0           // network protocol, 0 = don't care
                   );
  if (hSocket == INVALID_SOCKET) {cout << "ERROR in socket create\n"; return 1;}

  cout << "\nUDP Server: Evaluates int arithmetic expressions.";
  cout << "\n            Receiving on port # " << PORT;
  // 3. Initialize address info about the socket 
  memset(&SockAddr, 0, sizeof(SockAddr)); // zero struct sockaddr_in

  SockAddr.sin_family      = AF_INET;      // set address family as Internet
  SockAddr.sin_port        = htons(PORT);        // port address (service #)
  SockAddr.sin_addr.s_addr = htonl(INADDR_ANY);  // The local IP address
                   // "INADDR_ANY" requests software to assign local IP

  // 4. Binds IP address and Port # to the socket
  status = bind (
             hSocket,                // socket 'handle'
             (LPSOCKADDR) &SockAddr, // server IP addr and port #
             sizeof(SockAddr)        // length of the socket addr struct
                );
  if (status == SOCKET_ERROR) {cout << "ERROR in bind()\n"; return 1;}

  // 5. Loop: (a) receive 'input' from a client, 
  //          (b) process, 
  //          (c) return result

  cout << "\nServer socket waiting for requests . . . "; cout.flush();
  int           nBytesRecvd;
  int           nBytesSent;
  SOCKADDR_IN   ClientSockAddr;          // will hold addr of client
  int addrLen = sizeof (ClientSockAddr);

  struct SExpr  Expr;
  while(1)
  { 
    // (a) Receive input from client
    nBytesRecvd = recvfrom (   // returns # bytes received
           hSocket,      // handle of local socket
           (char *)&Expr,
           sizeof Expr,
           NO_FLAGS_SET, //
           (LPSOCKADDR)&ClientSockAddr, // Addr of client machine
           &addrLen                     // length of addr struct
                           );
    if (nBytesRecvd == SOCKET_ERROR)
    {
      cout << "ERROR in recvfrom()\n"; cout.flush(); getch();
      closesocket(hSocket); WSACleanup(); return 1; 
    }
    // (b) Process input
    switch (Expr.op)
    {
    case '+':
      cout << "\n  Addition performed...";
      Expr.result = Expr.x + Expr.y;
      break;
    case '-':
      cout << "\n  Subtraction performed...";
      Expr.result = Expr.x - Expr.y;
      break;
    case '*':
      cout << "\n  Multiplication performed...";
      Expr.result = Expr.x * Expr.y;
      break;
    case '/':
      cout << "\n  int Division performed...";
      Expr.result = Expr.x / Expr.y;
      break;
    default:
      break;
    }
    cout.flush();

    // (c) Sent result to client
    nBytesSent = sendto (
           hSocket,
           (char *)&Expr,
           sizeof Expr,
           //buffer,
           //strlen(buffer) + 1,
           NO_FLAGS_SET,
           (LPSOCKADDR) &ClientSockAddr, // holds client addr: IP, port
           sizeof(ClientSockAddr)
                        );
   if (nBytesSent != (int)sizeof(Expr) )
   {
     cout << "\n  Problem with sendto(). Connection terminated.\n";
     closesocket (hSocket); WSACleanup(); return 1;
   }
  } // while end

}
