//**************************************
// Original program by Marshall Brain
// Extensively modified by R. Jones for readability, etc
//**************************************
// Server:   mciprecv.cpp

#include <windows.h>
#include <iostream.h>
#include <winsock.h>

#define NO_FLAGS_SET 0
#define PORT        (u_short)44966
#define MAXBUFLEN   256

INT main(VOID)
{
  WSADATA     wsaData;
  SOCKET      hSocket;           // like a handle, descriptor 
  SOCKADDR_IN SockAddr;          // address info about socket
  char        buffer[MAXBUFLEN]; // where msg placed

  // 1. Initialize WSA: Window Socket A'PI, the DLL
  int status;
  status = WSAStartup (       
              MAKEWORD(1, 1), // Version # of winsock lib
              &wsaData        // Data about winsock implementation: E.g.:
                              //    Max sockets, Max UDP datagram size, etc
                      );
  if (status != 0) cerr << "ERROR: WSAStartup unsuccessful\n";

  // 2. Create a socket. Essentially, specifies protocol.  
  hSocket = socket (      // Returns a "handle" to the socket, a descriptor
                 AF_INET,    // "addr family" otherwise socket domain 
                 SOCK_DGRAM, // socket type: SOCK_DGRAM = UDP, SOCK_STREAM = TCP
                 0           // network protocol, 0 = don't care
                   );
  if (hSocket == INVALID_SOCKET) {cerr << "ERROR: socket unsuccessful\n"; return 1;}

  // 3. Initialize address info about the socket, 'sockaddr_in' struct 
  memset(&SockAddr, 0, sizeof(SockAddr)); // zero struct sockaddr_in

  SockAddr.sin_family      = AF_INET;      // set address family as Internet
  SockAddr.sin_port        = htons(PORT);        // port address (service #)
  SockAddr.sin_addr.s_addr = htonl(INADDR_ANY);  // An IP address
                            // "INADDR_ANY" to request local IP addr be assigned

  // 4. Bind: "Names" the local socket with values in the 'sockaddr_in' struct
  status = bind (
             hSocket,                // socket 'handle'
             (LPSOCKADDR) &SockAddr, // ptr to socket addr struct
             sizeof(SockAddr)        // length of the socket addr struct
                );
  if (status == SOCKET_ERROR) {cerr << "ERROR: bind unsuccessful\n"; return 1;}

  // 5. Loop: get msg from client and display 
  int nBytesRecvd;
  while(1)
  {
    nBytesRecvd = recvfrom (      // returns the num bytes received
                    hSocket, // 'handle' of the socket
                    buffer,     // where messaga placed
                    MAXBUFLEN,  // buffer length
                    NO_FLAGS_SET, //
                    NULL,         // 'from addr, ptr to'. has source addr and port #
                    NULL          // length of socket struct
                      );
    if (nBytesRecvd == SOCKET_ERROR)
    {
      cerr << "ERROR: recvfrom() unsuccessful\n";
      status = closesocket(hSocket);
      if (status == SOCKET_ERROR) cerr << "ERROR: closesocket unsuccessful\n";
      status = WSACleanup();
      if (status == SOCKET_ERROR) cerr << "ERROR: WSACleanup unsuccessful\n";
      return(1); 
    }
    cout << buffer << endl;
  } /* while */
}
