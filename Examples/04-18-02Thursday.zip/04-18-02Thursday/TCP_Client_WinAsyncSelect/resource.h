//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyResScript.rc
//
#define IDR_MENU1                       101
#define ID_ED_IP                        103
#define ID_ED_PORT                      104
#define ID_ED_SEND_MSG                  105
#define ID_LB_RECV_MSG                  106
#define ID_CONNECT                      40001
#define ID_SEND                         40002
#define ID_TERMINATE                    40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
