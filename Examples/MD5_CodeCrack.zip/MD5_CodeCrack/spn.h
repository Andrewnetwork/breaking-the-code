// Creates a spn if the user hasn't specified one.
void MakeSpn(unsigned char **pszSpn);
