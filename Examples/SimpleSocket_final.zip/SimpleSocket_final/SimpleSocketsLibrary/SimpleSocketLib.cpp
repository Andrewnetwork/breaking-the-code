// This is the main DLL file.

#include "stdafx.h"

#include "SimpleSocket.h"
#include "SimpleClientSocket.h"
#include "SimpleServerSocket.h"
#include "SocketCommunicator.h"

