#include "TransmitFileSimple.h"
#include <Windows.h>
#include <string>
#include <fstream>
#include <iostream>

using namespace std;

const unsigned int bufferSize = 500; 

TransmitFileSimple::TransmitFileSimple( SOCKET activeConnection )
{
	this->activeConnection = activeConnection; 
}


// Return true if sending the file was a success.
bool TransmitFileSimple::sendFileWithName( string filePath )
{
	ifstream inputFile( filePath.c_str() , ios::binary);
	
	char strBuffer[ bufferSize ];
	char nameBuffer[ bufferSize ] = { '\0' };
	char ackBuffer[1];

	int bytesReceived;

	// Copy file name into the sending buffer. 
	strncpy( nameBuffer, filePath.c_str(), filePath.size() );

	if (send(this->activeConnection, nameBuffer, bufferSize, 0) == SOCKET_ERROR)
	{
		// Could not send part of the file. 
		return false; 
	}

	bytesReceived = recv(this->activeConnection, ackBuffer, 1, 0);

	if ( bytesReceived != 1 || ackBuffer[0] != 'C' )
	{
		return false; 
	}


	

	while( !inputFile.eof() )
	{
		inputFile.read( strBuffer, bufferSize );

		if (send(this->activeConnection, strBuffer, bufferSize, 0) == SOCKET_ERROR)
		{
			// Could not send part of the file. 
			return false; 
		}

		bytesReceived = recv(this->activeConnection, ackBuffer, 1, 0);

		if ( bytesReceived != 1 || ackBuffer[0] != 'C' )
		{
			return false; 
		}

	}

	cout<<"EOF"<<endl;

	// End transmission.
	send(this->activeConnection, "E", 1, 0);

	return true; 
}