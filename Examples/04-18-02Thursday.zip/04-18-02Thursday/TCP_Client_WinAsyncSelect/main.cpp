// Project: TCP_Client_Win2_WSAsyncSelect

#include <afxwin.h>
#include "resource.h"
 
// - - - prototype - - - 
LRESULT CALLBACK MyWndProc (HWND hWnd, UINT msg,
                            WPARAM wP, LPARAM lP) ;

int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst,
                    PSTR sCmdLine, int iCmdShow)
{
  HWND         hWnd ;
  MSG          msg ;
  WNDCLASS     wc ; // This is just a struct
  TCHAR wcName[] = TEXT("TypicalWindow") ;

  // Step 1: Register a window 'class'
  wc.lpszClassName = wcName ;
  wc.lpfnWndProc   = MyWndProc; // Function that handles messages
                                // to windows based on this 'class'
  wc.style         = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS  ;
  wc.hIcon         = LoadIcon   (NULL, IDI_APPLICATION) ;
  wc.hCursor       = LoadCursor (NULL, IDC_ARROW) ;

  // Option 1 Specifies a white window background
  // wc.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH) ;
  
  // Option 2 Specifies a non-white background color 
   HBRUSH  hBrush;
   hBrush = CreateSolidBrush (RGB(150,255,150));
   wc.hbrBackground = hBrush; 

  wc.lpszMenuName  = MAKEINTRESOURCE(IDR_MENU1);
  wc.hInstance     = hInst ;
  wc.cbClsExtra    = 0 ;
  wc.cbWndExtra    = 0 ;

  if (!RegisterClass (&wc)) return 0;

  // Step 2: Create window based on above registered 'class'
  hWnd = CreateWindow
         (
          wcName,        // Name of the "registed class"
          TEXT ("TCP Client Win2: Detects socket events with WSAAsyncSelect"), // Window title
          WS_OVERLAPPEDWINDOW, // window style
          50,             // window position, left edge
          90,             // window position, top edge
          430,            // initial window width
          290,            // initial window height
          NULL,           // parent window handle
          NULL,           // window menu handle
          hInst,          // program instance handle
          NULL            // creation parameters
         ) ;                     
     
  // Step 3: Show and update the window
  ShowWindow (hWnd, iCmdShow) ;
  UpdateWindow (hWnd) ;

  // Step 4: Retrieve messages from message queue.
  while (GetMessage (&msg, NULL, 0, 0))
  {
     TranslateMessage (&msg) ;
     DispatchMessage (&msg) ;// Give message back to OS.
                             // Sends to appro 'WndProc'
  }
  DeleteObject (hBrush); // Comment out if
                         //  use background option 1
  return msg.wParam ;
}


#include      <winsock.h>
#include      "QkEditCtrl.h"
#include      "QkListboxCtrl.h"

#define        WM_SOCKET_NOTIFY   (WM_USER + 1)
#define        NO_FLAGS_SET       0
#define        MAXBUFLEN          256

WSADATA        wsaData;
SOCKET         hSocket;
SOCKADDR_IN    SockAddr;
int            status;

CQkEditCtrl    Ed_IP;
CQkEditCtrl    Ed_Port;
CQkEditCtrl    Ed_SendMsg;
CQkListboxCtrl Lb_RecvMsg; // & other info

LRESULT CALLBACK MyWndProc (HWND hWnd, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
  HDC            hDC ;  // 
  PAINTSTRUCT    ps  ;  // Invalid window info
     
  switch (message)
  {
  case WM_CREATE:
         Ed_IP.Create (hWnd, ID_ED_IP,      CPoint(10,3),  "Enter IP addr", 100);
       Ed_Port.Create (hWnd, ID_ED_PORT,    CPoint(13,35), "     Enter Port", 100);
    Ed_SendMsg.Create (hWnd, ID_ED_SEND_MSG,CPoint(10,68),
          "Enter outgoing message. Select 'Send'", 400, EDT_PROMPT_ABOVE);
    Lb_RecvMsg.Create(hWnd, ID_LB_RECV_MSG, CPoint (10,140), 400,95);

         Ed_IP.Show(hWnd);
       Ed_Port.Show(hWnd);
    Ed_SendMsg.Show(hWnd);
    Lb_RecvMsg.Show();

    Ed_IP.SetValue ("127.0.0.1");
    Ed_Port.SetValue ("44965");
    return 0 ;

  case WM_PAINT:
    hDC = BeginPaint (hWnd, &ps) ;
    SelectObject (hDC,GetStockObject (HOLLOW_BRUSH));
    SetBkMode(hDC,TRANSPARENT);
         Ed_IP.ShowPrompt(hDC);
       Ed_Port.ShowPrompt(hDC);
    Ed_SendMsg.ShowPrompt(hDC);
    TextOut (hDC,10,120,"Info & received messages", 24);
    EndPaint (hWnd, &ps) ;
    return 0 ;

  case WM_COMMAND:
    {
      switch (LOWORD (wParam))
      {
      case ID_CONNECT:
        // 1. Initialize WSA
        status = WSAStartup (MAKEWORD(1,1), &wsaData);
        if (status != 0)
          Lb_RecvMsg.StrAdd("Error: WSAStartup");

        // 2. Create socket
        hSocket = socket (AF_INET, SOCK_STREAM, 0);
        if (hSocket == INVALID_SOCKET)
          Lb_RecvMsg.StrAdd("Error: Socket create");

        // 3. Initialize address
        {
          char Server_IP_Addr[40];
          long int LongPort;
          u_short  port;

          Ed_IP.GetCharStr(Server_IP_Addr);
          Ed_Port.GetInt(LongPort);
          port = (u_short)LongPort;
          SockAddr.sin_family      = AF_INET;
          SockAddr.sin_addr.s_addr = inet_addr(Server_IP_Addr);
          SockAddr.sin_port        = htons(port);
        }
        status = connect ( hSocket,
                           (LPSOCKADDR) &SockAddr,
                           sizeof(SockAddr)
                          );
        if (status == SOCKET_ERROR)
          Lb_RecvMsg.StrAdd("Error: Connect");
        else
          Lb_RecvMsg.StrAdd("Connected okay");
        
        // 4. Initialize to Receive Socket Events
        status = WSAAsyncSelect (hSocket,hWnd, WM_SOCKET_NOTIFY, FD_READ);
        if (status == SOCKET_ERROR)
          Lb_RecvMsg.StrAdd("Select error");
        break;

      case ID_SEND:
        {
          char  sendText[MAXBUFLEN];
          int   nBytesSent;
          
          Ed_SendMsg.GetCharStr(sendText);
          
          nBytesSent = send (hSocket, sendText, strlen(sendText) + 1, NO_FLAGS_SET);
          if (nBytesSent != (int)strlen(sendText) + 1)
            Lb_RecvMsg.StrAdd ("Send problem");
          else
            Lb_RecvMsg.StrAdd ("Message sent");
          break;
        }

      case ID_TERMINATE:
        Lb_RecvMsg.StrAdd ("shutdown & closing socket"); 
        shutdown    (hSocket,2);
        closesocket (hSocket);
        WSACleanup  ();
        break;
        
      default:
        break;
      } // end switch
      return 0;
    }

  case WM_SOCKET_NOTIFY:
    {
      WORD   wEvent, wError;
      wEvent = WSAGETSELECTEVENT (lParam);
      wError = WSAGETSELECTERROR (lParam);
      switch (wEvent)
      {
      case FD_READ:
        {
          char   recvText[MAXBUFLEN];
          int    nBytesRecvd;
          
          nBytesRecvd = recv ( hSocket,recvText,MAXBUFLEN,NO_FLAGS_SET );
          if ( (nBytesRecvd==0) || (nBytesRecvd == SOCKET_ERROR) )
            Lb_RecvMsg.StrAdd("Recv problem");
          else
            Lb_RecvMsg.StrAdd(recvText);
          break;
        }
      default:
        break;
      } // switch end
      return 0;
    }

  case WM_DESTROY:
       PostQuitMessage (0) ;
       return 0 ;
  }
  return DefWindowProc (hWnd, message, wParam, lParam) ;
}