// QkButton.h

#if !defined(_QKBUTTON_H_)
#define _QKBUTTON_H_

#include <afxwin.h>

class CQkButton  
{
public:
	CQkButton();
	virtual ~CQkButton();

  void  Create     (HWND    hWnd, 
                    UINT    id,
                    CPoint  xyPosition,
                    CString Caption,
                    int Width = 0, int Height = 0);
  void  Show       ();
	void  Hide       ();
  UINT  GetButtonID(); 


  HWND     hParent;
  UINT     mID;
  CPoint   mPosition;
  CString  mCaption;
  int      mWidth;
  int      mHeight;
  BOOL     mVisible;

  HWND     hButtonWnd;


};

#endif
