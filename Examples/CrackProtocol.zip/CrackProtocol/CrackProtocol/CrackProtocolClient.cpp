// CrackProtocolClient.cpp
// Andrew Ribeiro
// April 10, 2011

#include <Windows.h>
#include <string> 
#include <vector>
#include <sstream>
#include <fstream>

#include "..\GlobalHeaders\SimpleSocketsLibrary\SimpleClientSocket.h"
#include "..\GlobalHeaders\SimpleSocketsLibrary\SimpleSocket.h"
#include "..\GlobalHeaders\SimpleSocketsLibrary\SocketCommunicator.h"
#include "..\GlobalHeaders\CrackProtocolConstants.h"

#include "Permutation.h"
#include "CrackProtocolClient.h"

using namespace AndrewRibeiro; 
using namespace std; 

void printCounterVector( vector<unsigned char> vect , unsigned char base);
void PushStringOntoBuffer(char *str);


//##### Public Methods ########

// Constructor
CrackProtocolClient::CrackProtocolClient( SOCKET activeConnection)
{
	this->connection                = activeConnection; 
	this->connectionCom             = new SocketCommunicator( activeConnection );
}

// Protocol Functions 

//void requestInformation();

bool CrackProtocolClient::startProcess( string name, string email, string verificationArchPath )
{
	// If a code is not currently being cracked.
	if( ! this->getProcessStatus() )
	{
		this->connectionCom->write(KEY_START_PROCESS);

		this->connectionCom->write(name);

		this->connectionCom->write(email);

		this->connectionCom->write( getFileContents( verificationArchPath ) );

		return true; 
	}
	else
	{
		return false;
	}
}

bool CrackProtocolClient::getProcessStatus()
{
	this->connectionCom->write(KEY_GET_PROCESS_STATUS );

	return atoi( this->connectionCom->read().c_str() );;
}

void CrackProtocolClient::rangeComplete( string crackedCode )
{
	this->connectionCom->write( KEY_RANGE_COMPLETE );

	if( crackedCode.size() == 0 )
	{
		string garbage ="";
		garbage += BLANK_CHAR;
		this->connectionCom->write( garbage );
	}
	else
	{
		this->connectionCom->write( crackedCode );
	}
}

pair<vector<unsigned char>, vector<unsigned char> > CrackProtocolClient::getRange()
{
	string messageBuffer;
	char charToNum[3];

	messageBuffer+="Getting permutation range from server.\n";

	pair<vector<unsigned char>, vector<unsigned char> > rangeOut;

	vector<unsigned char> lowerBound;
	vector<unsigned char> upperBound;

	this->connectionCom->write( KEY_GET_RANGE );

	string serverMessage; 

	serverMessage = this->connectionCom->read();

	lowerBound.resize( serverMessage.size() );

	messageBuffer += "  Range Start: | ";

	for( int i = 0; i < serverMessage.size(); i++)
	{
		lowerBound[i] = serverMessage[i];

		itoa((int)lowerBound[i],charToNum,10 );

		messageBuffer += charToNum;
		messageBuffer += " | ";
	}

	messageBuffer += "\n";

	serverMessage = this->connectionCom->read();

	upperBound.resize( serverMessage.size() );
	
	messageBuffer += "  Range End: | ";

	

	for( int i = 0; i < serverMessage.size(); i++)
	{
		upperBound[i] = serverMessage[i];

		itoa((int)upperBound[i],charToNum,10 );

		messageBuffer += charToNum;
		messageBuffer += " | ";
	}

	messageBuffer += "\n";
	
	rangeOut.first = lowerBound;
	rangeOut.second = upperBound;

	PushStringOntoBuffer( (char *) messageBuffer.c_str() );

	return rangeOut;
}

// RETURN: Path to verification folder receved. 
string CrackProtocolClient::getVerificationArchive()
{
	this->connectionCom->write( KEY_GET_VERIFICATION_ARCHIVE );

	makeDirectory( "VerificationFolder.zip" , this->connectionCom->read() );

	unzipFile( "VerificationFolder.zip" );

	return "VerificationFolder";
}


//##### Private Methods ########

string CrackProtocolClient::getFileContents( string filePath )
{
	stringstream strStream;

	ifstream inputFile( filePath , ios::binary | ios::in);

	inputFile.seekg (0, ios::end);
	int fileLength = inputFile.tellg();
	inputFile.seekg (0, ios::beg);

	char * fileBuffer  = new char[ fileLength ];

	inputFile.read(fileBuffer, fileLength );
	strStream.write(fileBuffer, fileLength );
		
	return strStream.str();
}



string CrackProtocolClient::requestInformation()
{
	// Jaynam's Job...
	// The output string should be ready to print directly to the screen.
	// Use \n to indicate new lines. 
	// The > character will be automatically added to new lines. 

	return "";
}


bool CrackProtocolClient::unzipFile( string name )
{
	STARTUPINFO         startUpInfo;
	PROCESS_INFORMATION procInfo;
	BOOL                success;
	char                appName[256];
	DWORD               processExitCode; 
	LPDWORD			  ptrProccessExitCode = &processExitCode; 

 
	strcpy (appName, "7zip\\7z.exe\0" );

	// 2. Retrieve the STARTUPINFOR structure for current process
	GetStartupInfo(&startUpInfo);

	string args = "7z x -y ";
	args += name;

	// 3. Create the child process
	success = CreateProcess(
					appName, // or NULL    // app. name
					(LPSTR)args.c_str(),    // c:\ ... // command line
					NULL,   // security
					NULL,   // thread security
					FALSE,  // do not inherit handles of parent process
					DETACHED_PROCESS, // various constants
					NULL,      // points to array of string containing environment variables
					NULL,      // Starting drive and directory for the process
					&startUpInfo, // appearance ifno
					&procInfo     // return info for process
							);


	WaitForSingleObject( procInfo.hProcess, INFINITE );

	return success;
}

bool CrackProtocolClient::makeDirectory( string name, string bin )
{
	fstream outFile( name , ios::app | ios::binary);

	outFile.write( bin.c_str() , bin.size() );

	outFile.close();

	return !outFile.fail();
}