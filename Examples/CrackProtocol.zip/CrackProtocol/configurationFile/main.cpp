
#include <iostream>
#include <map>
#include <string>
#include <fstream>

using namespace std;


map<string,string> getConfigurationVariables()
{
	map<string,string> configVars;

	ifstream configFile("config.txt",ios::in);

	string line;
	int indexOfFirstSpace;

	while( !configFile.eof() )
	{
		getline( configFile,line,'\n');

		indexOfFirstSpace = line.find_first_of(' ');

		if( indexOfFirstSpace != string::npos )
		{

			configVars.insert( pair< string, string >( line.substr(0,indexOfFirstSpace ), line.substr(indexOfFirstSpace+1, line.size() - indexOfFirstSpace ) ) ); 
		}
	}

	return configVars;
}

void main()
{
	map<string,string> config = getConfigurationVariables();

	cout<<"Port: |"<<config["port"]<<"|"<<endl
		<<"Name: |"<<config["name"]<<"|"<<endl;

	system("pause");
}