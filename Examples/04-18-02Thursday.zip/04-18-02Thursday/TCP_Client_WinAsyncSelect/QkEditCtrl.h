// QkEditCtrl.h

// 1. This class gives the you (the programmer) the
//    ability to present an edit ctrl to the user
//    where information is entered.

// 2. You don't have to know anything about this
//    class EXCEPT how to use the 6 or 7 methods.

#if !defined(_QKEDITCTRL_H_)
#define _QKEDITCTRL_H_

#include <afxwin.h>
#include "utility.h"

// These are styles for the InputBox.
#define EDT_PROMPT_INLINE  0
#define EDT_PROMPT_ABOVE   1

class CQkEditCtrl  
{
public:
	         CQkEditCtrl();
	virtual ~CQkEditCtrl();

  void  Create     (HWND hWnd, UINT ID, CPoint xyPosition, CString Prompt, int Width, int style = 0);
  void  Show       (HWND hWnd); // Show the prompt and the EditCtrl
  void  ShowPrompt (HDC hDC);
             // This is used in OnPaint() if you want 
             //   to keep the prompt showing 
             //   after a re-painting of the screen.
	void  Hide       (HWND hWnd);

  void  GetCString (CString& s,  int n = 0);
  void  GetInt     (long&    i,  int n = 0);
  void  GetDouble  (double&  d,  int n = 0);
  void  GetCharStr (char     s[]  );
	void  SetValue   (CString  s    );
  
  void  Destroy    ();
  HWND  GetHandle  ();
  UINT  GetObjectID();

private:
  CPoint   mPosition;
  CString  mPrompt;
  int      mWidth;
  BOOL     mVisible;

  HWND     hEditWnd;
  HWND     hParent; // Used to give focus back to parent window
  UINT     mID;

       // The above is a 'class' variable.
       // It is not a member of each object!
       // It is global to all objects.  Only one exists!
       // We use it to gives each window an ID.
};

#endif
