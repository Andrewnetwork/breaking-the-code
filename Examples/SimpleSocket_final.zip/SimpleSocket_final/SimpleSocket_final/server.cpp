#include <iostream>
#include "..\SimpleSocketsLibrary\SimpleServerSocket.h"
#include "..\SimpleSocketsLibrary\SocketCommunicator.h"

using namespace std; 
using namespace AndrewRibeiro;

void main()
{
	SimpleServerSocket serverSock;
	SocketCommunicator * serverToClientCom;

	serverSock.bindToPort("8203");
	SOCKET client = serverSock.listenForConnection();

	serverToClientCom = new SocketCommunicator( client );

	while( true )
	{
		string outMessage; 

		// Send message.
		cout<<"To client ( enter nothing to end ): ";
		getline( cin, outMessage, '\n' );

		if( outMessage.length() <= 0 )
		{
			cout<<"End of communication."<<endl;
			break;
		}
		serverToClientCom->write( outMessage );
	
	}

	closesocket( client );

	system("pause");
}