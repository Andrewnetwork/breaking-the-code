//***********************************
// Project: TCP_Server_Mul by Marshall Brain
// Modified extensively by RMJ
// Project settings:
//                   Link tab: wsock32.lib
//   C++ tab, code generation: multi-threaded DLL
// TCP server handles multiple clients.
// Receives: a string
// Returns:  the string in uppercase
//***********************************
#include <windows.h>
#include <iostream.h>
#include <winsock.h>
#include <process.h> //for multi-threading

#define NO_FLAGS_SET    0
#define PORT            (u_short)44965
#define MAXBUFLEN       256

VOID talkToClient(VOID *cs)
{
  cout << "\n  Another thread created . . .\n";
  cout.flush();
  char    buffer[MAXBUFLEN];
  //int     status;
  int     nBytesSent;
  int     nBytesRecvd;
  SOCKET  clientSocket = (SOCKET)cs;

  while(1)
  {
    // (a) Receive 
    nBytesRecvd = recv (
                   clientSocket, // holds address of client 
                   buffer,       // message
                   MAXBUFLEN,    //
                   NO_FLAGS_SET
                       );
    cout << "\nMessage received: " << buffer; cout.flush();
    if ((nBytesRecvd == 0) || (nBytesRecvd == SOCKET_ERROR))
    {
      // nBytesRecvd = 0 indicates  graceful shutdown.
      cout << "\nConnection thread terminated\n"; cout.flush();
      break;
    }
    // (b) Process. Obviously, this could be much more involved
    _strupr(buffer);            // converts string to uppercase

    // (c) Send results back to client
    nBytesSent = send (
                   clientSocket, // to address of client
                   buffer,       // results
                   strlen(buffer) + 1,
                   NO_FLAGS_SET
                      );
    if (nBytesSent != (int)strlen(buffer) + 1)
    {
      cout << "Connection terminated.\n"; cout.flush();
      break;
    }
  } // while end

  // terminate the connection with the client
  shutdown    ( clientSocket, 2);
  closesocket ( clientSocket );
}

INT main(VOID)
{
  WSADATA      wsaData;
  SOCKET       serverSocket;
  SOCKADDR_IN  serverSockAddr;


  int          addrLen = sizeof(SOCKADDR_IN);
  DWORD        threadID;

  cout << "\nTCP Server Multi-threaded to handle multiple clients";
  cout << "\n  Waiting for client connections . . .\n";
  cout.flush();
  // 1. Initialize WSA, the Window Socket API
  int status;
  status = WSAStartup ( MAKEWORD(1, 1), &wsaData );
  if (status != 0) { cerr << "ERROR in WSAStartup\n"; return 1; }

  // 2. Create a socket
  serverSocket = socket (
                    AF_INET,
                    SOCK_STREAM,
                    0
                        );
  if (serverSocket == INVALID_SOCKET)
  {
    cerr << "ERROR in socket create\n";
    status = WSACleanup();
    if (status == SOCKET_ERROR) cerr << "ERROR in WSACleanup\n";
    return 1 ;
  }

  // 3. Initialize server socket info 
  memset(&serverSockAddr, 0, sizeof(serverSockAddr));
  serverSockAddr.sin_family       = AF_INET;
  serverSockAddr.sin_addr.s_addr  = htonl(INADDR_ANY);
  serverSockAddr.sin_port         = htons(PORT);

  // 4. Bind the socket with the address
  status = bind (
              serverSocket, 
              (LPSOCKADDR) &serverSockAddr,
              sizeof(serverSockAddr));
  if (status == SOCKET_ERROR) { cerr << "ERROR in bind()\n"; return 1;}

  // 5. Listen for connections
  status = listen ( serverSocket, 1 );
  if (status == SOCKET_ERROR) { cerr << "ERROR in listen()\n"; return 1;}

  SOCKET       clientSocket;
  SOCKADDR_IN  clientSockAddr;
  
  while(1)
  {
    // 6. Accept connection request when one received
    clientSocket = accept ( 
                     serverSocket,
                     (LPSOCKADDR) &clientSockAddr,
                     &addrLen
                          );
    if (clientSocket == INVALID_SOCKET) { cerr << "ERROR in accepting\n"; return 1; }

    threadID = _beginthread (
                    talkToClient,
                    0,
                    (VOID *)clientSocket
                            );
    if (threadID == -1)
    { 
      cerr << "ERROR in creating thread\n";
      status = closesocket(clientSocket);
      if (status == SOCKET_ERROR) cerr << "ERROR in closesocket\n";
    }

  } /* while */
}
