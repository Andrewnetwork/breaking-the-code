#ifndef SQL_XML_H
#define SQL_XML_H

#include <iostream>
#include <WinSock.h>
#include <string>
#include <vector>
#include <time.h>
#include <cstring>
#include <sstream>
#include <iostream>
#include <fstream>

#include <mysql.h>
#include "xmlwriter.h"

class SQL_XML {

public :
	SQL_XML();

	void check_connection 	( MYSQL* );						// Making or checking connection with Database
	void starting_info	  	( MYSQL*, string, string );		// Get user name and Email
	void ending_info	  	( MYSQL* , string );			// Get cracking code from client
	
	string execute_command  ( MYSQL*, string );				// Execute and print the result of SQL Query
	void SQL_Query 	    	(MYSQL*);						// Make and execute SQL Query
	
	void make_xml			( string );			// Creating xml and pass as a string
	string parse_xml		(string);						// Taking a string and parsing & print
	string read_xml			();

	void trial ( string );
private:
	
	vector <string> user_id,user_name,user_email;
	vector <string> proccess_id,code;
	vector <string> time_start,time_end;

	char u_id , p_id ;
	int count1 , count2;

	};
#endif