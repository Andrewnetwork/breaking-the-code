// CodeCrackingState.cpp
// Andrew Ribeiro 
// April 10, 2010

#include <vector>
#include <iostream>
#include <string>
#include <Windows.h>

#include "HeftyCounter.h"
#include "CodeCrackingState.h"

using namespace std;

void printCounterVector( vector<unsigned char> vect , unsigned char base);

const int CodeCrackingState::DEFAULT_PERM_INTERVAL = 100000;

CodeCrackingState::CodeCrackingState( )
{
	this->permutationCounter = NULL;
	this->verificationArchive = "";
	this->stateMutex = CreateMutex(NULL,false, NULL);
	this->clients = 0;

	newCounter();
}

// Accessors
string CodeCrackingState::getVerificationArchive()
{
	return this->verificationArchive;
}

unsigned int CodeCrackingState::getNClients()
{
	return this->clients;
}

bool CodeCrackingState::processStatus()
{
	return verificationArchive.size() > 0;
}

// Mutators
void CodeCrackingState::newCounter()
{
	if( this->permutationCounter != NULL )
	{
		delete this->permutationCounter;
	}

	// TODO: Remove magic numbers. 62 is the base of the alphabet. 
	this->permutationCounter = new HeftyCounter(1, 62);
}

void CodeCrackingState::clearVerificationArchive()
{
	this->verificationArchive = "";
}

void CodeCrackingState::setVerificationArchive( string binArchive)
{
	this->aquire();

	this->verificationArchive = binArchive;

	this->release();
}

void CodeCrackingState::addClient()
{
	this->aquire();

	this->clients++;

	this->release();
}

void CodeCrackingState::removeClient()
{
	this->aquire();

	this->clients--;

	this->release();
}
	


// Accessor/Mutator 
pair< vector<unsigned char>, vector<unsigned char> > CodeCrackingState::getRange( unsigned long int interval )
{
	this->aquire();

	pair< vector<unsigned char>, vector<unsigned char> > range = this->permutationCounter->getRange( interval );

	this->release();

	return range;
}

// Default interval of 100,000
pair< vector<unsigned char>, vector<unsigned char> > CodeCrackingState::getRange()
{
	this->aquire();
	
	pair< vector<unsigned char>, vector<unsigned char> > range = this->permutationCounter->getRange( DEFAULT_PERM_INTERVAL );

	this->release();

	printCounterVector( range.first , 62 );

	return range;
	
}



// Semaphore Methods
bool CodeCrackingState::aquire()
{
	WaitForSingleObject( this->stateMutex , INFINITE );

	return true;
}

bool CodeCrackingState::release()
{
	ReleaseMutex( this->stateMutex );

	return true;
}
