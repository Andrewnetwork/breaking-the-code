#include "Permutation.h"
#include <iostream>
using namespace std;

unsigned int alphabetCount( vector<char> * alphabet );

void main()
{
	// Setting up the alphabet. 
	// ACII Ranges of characters. Works in pairs. { lowerBound, upperBound }. 
	vector<char> alpha;
	alpha.push_back( 'A' );
	alpha.push_back( 'Z' );
	alpha.push_back( 'a' );
	alpha.push_back( 'z' );
	alpha.push_back( '0' );
	alpha.push_back( '9' );

	const unsigned int alphaSize = 62;

	unsigned long long permutationNum = 0;

	for( unsigned int stringLength = 1; true ; stringLength++ )
	{
		// Constructing permutation perm. 
		// First arg: Permutation string length. 
		// Second arg: Alphabet reference. 
		Permutation perm( stringLength, &alpha, alphabetCount(&alpha) );

		while( (permutationNum < pow( (long double) alphaSize , ( long double )stringLength )  )|| 
				( stringLength == 1 && permutationNum < alphaSize ) )
		{
			// Print permutation string. 
			//cout<<perm<<endl;

			// Increment permutation. 
			++perm;
			permutationNum++;
		}

		cout<<perm<<endl;
		permutationNum = 0;
		system("pause");
	}

	system("pause");
}