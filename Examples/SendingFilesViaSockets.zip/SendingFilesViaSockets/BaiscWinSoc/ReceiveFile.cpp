#include "ReceiveFile.h"
#include <Windows.h>
#include <string>
#include <fstream>
#include <iostream>

using namespace std;

const unsigned int bufferSize = 500; 

ReceiveFile::ReceiveFile( SOCKET activeConnection )
{
	this->activeConnection = activeConnection; 
}


// Return true if sending the file was a success.
string ReceiveFile::getFileWithName()
{
	char strBuffer[ bufferSize ]; 
	char nameBuffer[ bufferSize ];

	int bytesReceived = recv(this->activeConnection,  nameBuffer, bufferSize, 0);

	// TODO: Error proof this
	string fileName( nameBuffer );

	ofstream outputFile( fileName.substr(0,fileName.find_first_of('\0') ).c_str() , ios::binary);

	// Ready to continue. 
	if (send(this->activeConnection, "C", 1, 0) == SOCKET_ERROR)
	{
		// Could not send part of the file. 
		return "!Could not send a continue message after getting the file name."; 
	}

	bytesReceived = recv(this->activeConnection, strBuffer, bufferSize, 0);

	while( true )
	{
	
		if (bytesReceived == 1)  // connection closed
		{
			outputFile.close();
			return fileName.substr(0,fileName.find_first_of('\0') ).c_str();
		}
		else if (bytesReceived==SOCKET_ERROR)
		{
			// error handling code
			return "!e2"; 
		}

		outputFile.write( strBuffer, bufferSize ); 

		// Send continue message.
		if (send(this->activeConnection, "C", 1, 0) == SOCKET_ERROR)
		{
			// Could not send part of the file. 
			return "!e3"; 
		}

		// Continue receiving.
		bytesReceived = recv(this->activeConnection, strBuffer, bufferSize, 0);
	}
}