/***********************************************************************
*
* Example of using XmlStream class.
*  Author/Modifier: Jaynam Shah, April 4, 2011
* This code is provided "as is", with absolutely no warranty expressed
* or implied. Any use is at your own risk.
************************************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "xmlwriter.h"

using namespace std;
using namespace	xmlw;

void	xmlmake();
void	xmlparser();

int main()
{
	xmlmake();
	xmlparser();

  return 0;
}

void xmlmake()
{
	ofstream f("C:\\Users\\jaynam\\Desktop\\sample.xml");
	XmlStream xml(f);

  xml << prolog() // write XML file declaration
    << tag("codedata") // root tag
		<< tag("user1") // child tag
			<< tag("name") << chardata() << "Jaynam" << endtag("name") // close current tag
			<< tag("code") << chardata() <<"abc32AS" <<endtag("code") // sibling of <some-tag>
			<< tag("email") << chardata() << "abc@yahoo.com"<<endtag("email")
		<<endtag("user1")
    << endtag("codedata");

  
	system("pause");
}

void xmlparser()
{

	char temp;
	vector<char> first;
	vector<char> result;
	ifstream ifile("C:\\Users\\jaynam\\Desktop\\sample.xml", ios::in);
	if (ifile.fail())
	{
		cout<<" Failed to open input file."<<endl;
		system("pause");
	}
	else 
		for(int i = 0; !ifile.eof(); i++)
		{
			ifile>>temp;
			first.push_back(temp);			
		}

		for ( int i = 0; i < first.size();i++)
		{
			if (( first[i] =='>')&&(first[++i]!='<'))
			{
				do{
					result.push_back(first[i]);
					++i;
					if ( i >= first.size())
						break;
				}while ( first[i]!='<');
				result.push_back(' ');
			}
		}
	/*string address1, adress2, address3;

		for ( int i = 0; i < result.size(); i++)
		{
			if ( result[i]!=' '&& result[i]!='>')
				address1 += result[i];
		}*/
		int count = 0;
	
		for (int i = 0; i<result.size();i++)
		{
			
			while ( count != 3 &&  i < result.size() )
			{
				cout << result[i];
				if(result[i]==' ')
					count++;
				i++;
				
			}
			i--;
			cout<<endl;
			count = 0;
		}
		system("pause");
}