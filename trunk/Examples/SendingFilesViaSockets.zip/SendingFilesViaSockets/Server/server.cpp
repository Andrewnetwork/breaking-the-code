#include <iostream>
#include <Windows.h>
#include "TransmitFileSimple.h"

using namespace std; 



int main( int argc, char * args )
{
	const int iReqWinsockVer = 2;   // Minimum winsock version required

WSADATA wsaData;

	if (WSAStartup(MAKEWORD(iReqWinsockVer,0), &wsaData)==0)
	{
		// Check if major version is at least iReqWinsockVer
		if (LOBYTE(wsaData.wVersion) >= iReqWinsockVer)
		{
			/* ------- Call winsock functions here ------- */
			cout<<"This computer has Winsock 2!"<<endl;

			SOCKET hSocket;

			hSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
			if (hSocket != INVALID_SOCKET)
			{
				cout<<"Success in creating a socket."<<endl;

				/* This code assumes a socket has been created and its handle
				   is stored in a variable called hSocket */

				sockaddr_in sockAddr;

				sockAddr.sin_family = AF_INET;
				sockAddr.sin_port = htons(2034);
				sockAddr.sin_addr.S_un.S_addr = INADDR_ANY;

				// Bind socket to port 80
				if (bind(hSocket, (sockaddr*)(&sockAddr), sizeof(sockAddr)) == 0)
				{
					cout<<"Bound to port "<<sockAddr.sin_port<<"!!"<<endl;

					/* This code assumes the socket specified by
					   hSocket is bound with the bind function */

					if (listen(hSocket, SOMAXCONN) == 0)
					{
						cout<<"Listening on port "<<sockAddr.sin_port<<"!!"<<endl;

						sockaddr_in     remoteAddr;
						int             iRemoteAddrLen;
						SOCKET          hRemoteSocket;

						iRemoteAddrLen = sizeof(remoteAddr);
						hRemoteSocket = accept(hSocket, (sockaddr*)&remoteAddr, &iRemoteAddrLen);

						if (hRemoteSocket != INVALID_SOCKET)
						{
							while( true )
							{
								string fileOutPath;
								cout<<"Enter file path: ";
								getline(cin,fileOutPath );
							
								TransmitFileSimple transFile( hRemoteSocket );
								transFile.sendFileWithName( fileOutPath );

								cout<<"Sent file!"<<endl;

								cin.clear();
								cin.ignore(80,'\n');
							}

						}
						else
						{
							// error handling code
							cout<<"Could not connect to client."<<endl;
						}

						closesocket(hSocket);
					}
					else
					{
						// error handling code
						cout<<"Cannot listen to trafic on port "<<sockAddr.sin_port<<"!!"<<endl;
					}
				}
				else
				{
					// error handling code
					cout<<"Cannot bind to port."<<endl;
				}

				/* Note: the (sockaddr*) cast is necessary because connect requires a
				   sockaddr type variable and the sockAddr variable is of the sockaddr_in
				   type. It is safe to cast it since they have the same structure, but the
				   compiler naturally sees them as different types. */
			}
			else
			{
				// error handling code
				cout<<"Failure in creating a socket."<<endl;
			}
		}
		else
		{
			// Required version not available
			cout<<"Did not work!"<<endl;
		}

		// Cleanup winsock
		if (WSACleanup()!=0)
		{
			// cleanup failed
		}
	}
	else
	{
		//  startup failed
	}
	system("pause");
	return 0;
}