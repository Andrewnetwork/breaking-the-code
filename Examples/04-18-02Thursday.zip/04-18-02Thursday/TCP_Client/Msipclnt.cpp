//***************************************
// TCP_Client  Sends a string. 
//             Server return capitalized.
///**************************************
#include <windows.h>
#include <conio.h>
#include <iostream>
#include <winsock.h>
using namespace std;

#define NO_FLAGS_SET     0
#define MAXBUFLEN        256

int main(VOID)
{
  WSADATA       wsaData;
  SOCKET        hSocket;
  SOCKADDR_IN   SockAddr;
  int           status;

  // 1. Initialize WSA, the Window Socket API
  status = WSAStartup(MAKEWORD(1, 1), &wsaData);
  if (status != 0) {cerr << "ERROR in WSAStartup\n"; return 1;}

  // 2. Create a socket
  hSocket = socket (AF_INET, SOCK_STREAM, 0);
  if (hSocket == INVALID_SOCKET)
    { cerr << "ERROR in socket create()\n"; WSACleanup(); return 1;}
  cout << "\nTCP Client: Sends a string. Serve will capitalize.";

  // 3. Initialize 'sockaddr_in' with server info
  //    (a) Get IP addr of server
  char Server_IP_Addr[40];
  cout << "\n  Enter IP addr (0 = local host) of server ? ";
  cin.getline(Server_IP_Addr,40);
  if ( strcmp(Server_IP_Addr,"0") == 0) strcpy (Server_IP_Addr,"127.0.0.1");
  //    (b) Get port # for service
  u_short port;
  cout << "  Enter port # (44965?) for service ? "; cin >> port;
  //    (c) Assign values to addr struct 
  SockAddr.sin_family       = AF_INET;
  SockAddr.sin_addr.s_addr  = inet_addr(Server_IP_Addr);
  SockAddr.sin_port         = htons(port);

  // 4. Connect
  cout << "\n Trying to connect to IP Address: " << Server_IP_Addr << "\n";
  status = connect (
              hSocket,                  // This local (client) socket to the 
              (LPSOCKADDR) &SockAddr,  //  remote (server) IP addr and port
              sizeof(SockAddr)
                  );
  if (status == SOCKET_ERROR)
  { cerr << "ERROR in connect()\n"; closesocket (hSocket); WSACleanup();
    return 1;
  }
  cout << "\n Connected..." << endl;

  // 5. Send / Receive loop
  char    sendText[MAXBUFLEN];
  int     nBytesSent;
  char    recvText[MAXBUFLEN];
  int     nBytesRecvd;
  cin.getline(sendText, MAXBUFLEN); // eats carriage ret from 'cin>>port'
  while(1)
  {
    //  (a) Send
    cout << "\nType text ('0' = exit) to send ? "; cin.getline(sendText, MAXBUFLEN);
    if (strcmp(sendText,"0") == 0) break;

    nBytesSent = send (hSocket, sendText, strlen(sendText) + 1, NO_FLAGS_SET);

    if (nBytesSent != (int)strlen(sendText) + 1)
    { cout << "Send problem. Connection terminated.\n";
      closesocket(hSocket);  WSACleanup(); return 1;
    }

    //  (b) Wait for a response
    nBytesRecvd = recv(hSocket, recvText, MAXBUFLEN, NO_FLAGS_SET);

    if ((nBytesRecvd == 0) || (nBytesRecvd == SOCKET_ERROR))
    { cout << "Receive problem. Connection terminated.";
      closesocket(hSocket); WSACleanup(); return 1;
    }
    cout << "Received: " <<  recvText << endl;
  } // while end

  // 6. Terminate
  cout << "Connection terminating normally.\n <Press any key to exit>";
  cout.flush();
  shutdown    (hSocket,2); // Exchanges messages with server
  closesocket (hSocket);
  WSACleanup();
  getch();                 // wait for keystroke
  return 0;
}
