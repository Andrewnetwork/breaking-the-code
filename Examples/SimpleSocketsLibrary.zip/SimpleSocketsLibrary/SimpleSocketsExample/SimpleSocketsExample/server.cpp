// server.cpp
// Andrew Ribeiro 
// Andrew@AndrewRibeiro.com
// March 5, 2011

#include <iostream>
#include <sstream>

// Headers from SimpleSocketsLibrary
#include "SimpleServerSocket.h"
#include "SocketCommunicator.h"

// The namespace for the SimpleSocketsLibrary
using namespace AndrewRibeiro;

using namespace std;

// Function Prototypes
int computePrimes( int i );

void main()
{
	SimpleServerSocket    serverSock;
	SocketCommunicator *  clientCom         = NULL; 
	SOCKET                clientConnection  = NULL; 

	cout<<"---------------------------------- Server ------------------------------"<<endl;
	cout<<"This server responds to a client asking for the i'th prime number       "<<endl;
	cout<<"------------------------------------------------------------------------"<<endl<<endl;


	bool    clientConnectionError = false;
	string  serverPort;

	// Connect to client, and store socket/connection in 'clientConnection'
	do
	{
		cout<<"---------- Server Setup -----------"<<endl;
		cout<<"Enter server port: ";
		getline( cin, serverPort, '\n');

	
		cout<<"Waiting for incoming connections"<<endl;

		// # Connecting the the server 'serverIP', on port 'serverPort'
		clientConnection = serverSock.listenForConnection( serverPort );

		if( clientConnection == NULL )
		{
			// Unable to connect.
			clientConnectionError = true;
			cout<<"Could not connect to client on port '"<<serverPort<<"'."<<endl;
		}
		else
		{
			// Connected to the server. 
			clientConnectionError = false; 
		}

	}while( clientConnectionError );

	cout<<"Server connected to client on port '"<<serverPort<<"'."<<endl; 
	
	// # Create a socket communicator, so that we may communicate with the server using 'serverConnection'
	clientCom = new SocketCommunicator( clientConnection );


	// # Start conversation loop.

	bool    clientCommunicationError = false;

	do
	{
		string clientResult, clientOut;
	
		clientResult = clientCom->read();

		if( clientResult.length() > 0 )
		{
			// Prone to error, but error checking is left out in order to simplify this application.
			cout<<"I'th position from client: "<<clientResult<<endl;

			stringstream converter; 
			converter<<computePrimes( atoi( clientResult.c_str() ) )<<endl;
			converter>>clientOut;

			clientCom->write( clientOut );
		}
		else
		{
			cout<<"ERROR: Communication ended abruptly with client."<<endl;
			clientCommunicationError  = true;
		}

	}while( !clientCommunicationError ); 


	system("pause");
}


bool isPrime( int num )
{

	if( num == 2 || num == 3 )
	{
		return true; 
	}

	for( int i = 2; i <= (num / 2) ; i++ )
	{
		if( (num % i) == 0)
		{
			return false;
		}
	}

	return true;
}

int computePrimes( int i )
{
	int num = 2;
	int currentPrimeCounter = 0; 

	while( true )
	{
		if( isPrime( num ) )
		{
			currentPrimeCounter++;
		}

		if( currentPrimeCounter == i )
		{
			return num;
		}

		num++;
	}
}