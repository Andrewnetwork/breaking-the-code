// CodeCrackingState.h
// Andrew Ribeiro 
// April 10, 2010

#pragma once

#include <vector>
#include <string>

#include "HeftyCounter.h"

using namespace std;

class CodeCrackingState
{
public:

	CodeCrackingState( );

	// Accessors
	string getVerificationArchive(); 
	unsigned int getNClients();
	bool processStatus();
	

	// Mutators
	void setVerificationArchive( string binArchive);
	void addClient();
	void removeClient();
	void clearVerificationArchive();
	void newCounter();

	// Accessor/Mutator 
	pair< vector<unsigned char>, vector<unsigned char> > getRange( unsigned long int interval ); 

	// Uses the default interval
	pair< vector<unsigned char>, vector<unsigned char> > getRange(); 



	// Semaphore Methods
	bool aquire();
	bool release();
	bool wait();


private:

	unsigned int clients; 

	string verificationArchive; 

	HeftyCounter * permutationCounter;

	HANDLE stateMutex;

	static const int DEFAULT_PERM_INTERVAL;
};