// verificationProgram.cpp
// Andrew Ribeiro 
// April 11, 2011

// ### DONT TOUCH ###
#include <string>
#include <Windows.h>
#include <fstream>

#include "..\GlobalHeaders\SimpleSocketsLibrary\SimpleServerSocket.h"
#include "..\GlobalHeaders\SimpleSocketsLibrary\SimpleSocket.h"
#include "..\GlobalHeaders\SimpleSocketsLibrary\SocketCommunicator.h"

#include "VerificationServer.h"

using namespace std;
using namespace AndrewRibeiro;
// ### END DONT TOUCH ###

// ### START Custom Includes ###
#include "md5.h"
// ### END Custom Includes ###

// ### START Custom Using ###
// ### END Custom Using ###

// ### START Custom Function Prototypes ###
bool hashVerificationFunction( string permutation );
string MD5_string(string str);
// ### END Custom Function Prototypes ###

// ### START Custom Global Variables ###
string globalHash;
// ### END Custom Global Variables ###

void main( int argc, char * argv[] )
{
	if( argc == 2 )
	{
		string serverPort( argv[1] );
		VerificationServer verificationServer( serverPort );
	
		// ### START Customize Here ###
	
		ifstream hashFile("VerificationFolder\\hashFile.txt", ios::in );

		char hashIn[33];

		hashFile.getline(hashIn,33);

		hashFile.close();

		globalHash = hashIn;

		verificationServer.setVerificationFunction( hashVerificationFunction );

		// ### END Customize Here ###

		verificationServer.start();
	}
	else if( argc == 3 )
	{
		// Test mode.

		cout<<"Testing Verification Program"<<endl
			<<"Syntax: [garbage] [permutation]"<<endl<<endl;


		// ### START Customize Here ###

		ifstream hashFile("VerificationFolder\\hashFile.txt", ios::in );

		char hashIn[33];

		hashFile.getline(hashIn,33);

		hashFile.close();

		globalHash = hashIn;

		cout<<"Comparing "<<globalHash<<" with "<<MD5_string(argv[2])<<": "<<hashVerificationFunction( argv[2] )<<endl;

		// ### END Customize Here ###

	}
	else
	{
		cout<<"ERROR: Port number is needed as the first command line argument."<<endl;
	}
}


// ### START Custom Function Definition ####
string MD5_string(string str)
{
    MD5 context;
	unsigned int len = str.length();

	context.update((unsigned char *)str.c_str() , len);
    context.finalize ();

    return context.hex_digest();
  
}

bool hashVerificationFunction( string permutation )
{
	if( MD5_string( permutation ).compare( globalHash ) == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
// ### END Custom Function Definition ####