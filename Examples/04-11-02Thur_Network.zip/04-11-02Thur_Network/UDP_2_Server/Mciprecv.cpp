//**************************************
// Project: UDP_2_Server 
// Server
//   Receives a string from a client
//   Returns the capitalized string
//**************************************
#include <windows.h>
#include <iostream.h>
#include <winsock.h>

#define NO_FLAGS_SET 0
#define PORT        (u_short)44966
#define MAXBUFLEN   256

int main(VOID)
{
  WSADATA     wsaData;
  SOCKET      hSocket;           // Handle to the socket 
  SOCKADDR_IN SockAddr;          // IP address and Port for service
  char        buffer[MAXBUFLEN]; // where msg placed

  // 1. Initialize WSA: Window Socket A'PI, the DLL
  int status;
  status = WSAStartup (       
              MAKEWORD(1, 1), // Version # of winsock lib
              &wsaData        // Data about winsock implementation: E.g.:
                              //    Max sockets, Max UDP datagram size, etc
                      );
  if (status != 0) cerr << "ERROR in WSAStartup()\n";

  // 2. Create a socket. Essentially, specifies protocol.  
  hSocket = socket (      // Returns a "handle" to the socket, a descriptor
                 AF_INET,    // "addr family" internet 
                 SOCK_DGRAM, // socket type: SOCK_DGRAM = UDP, SOCK_STREAM = TCP
                 0           // network protocol, 0 = don't care
                   );
  if (hSocket == INVALID_SOCKET) {cerr << "ERROR in socket create\n"; return 1;}

  // 3. Initialize address info about the socket 
  //memset(&SockAddr, 0, sizeof(SockAddr)); // zero struct sockaddr_in

  SockAddr.sin_family      = AF_INET;      // set address family as Internet
  SockAddr.sin_port        = htons(PORT);        // port address (service #)
  SockAddr.sin_addr.s_addr = htonl(INADDR_ANY);  // The local IP address

  // 4. Binds IP address and Port # to the socket
  status = bind (
             hSocket,                // socket 'handle'
             (LPSOCKADDR) &SockAddr, // server IP addr and port #
             sizeof(SockAddr)        // length of the socket addr struct
                );
  if (status == SOCKET_ERROR) {cerr << "ERROR in bind()\n"; return 1;}

  cout <<   "UDP Server: Capitalizes messages received.";
  cout << "\n            Receiving on port # " << PORT;
  // 5. Loop: (a) receive 'input' from a client, 
  //          (b) process, 
  //          (c) return result

  cout << "\nServer socket waiting for requests . . .\n"; cout.flush();
  int           nBytesRecvd;
  int           nBytesSent;
  SOCKADDR_IN   ClientSockAddr;          // will hold addr of client
  int addrLen = sizeof (ClientSockAddr);
  int MsgCount = 0;
  while(1)
  { 
    // (a) Receive input from client
    nBytesRecvd = recvfrom (   // returns # bytes received
           hSocket,      // handle of local socket
           buffer,       // where input message placed
           MAXBUFLEN,    // buffer length
           NO_FLAGS_SET, //
           (LPSOCKADDR)&ClientSockAddr, // Addr of client machine
           &addrLen                     // length of addr struct
                           );
    if (nBytesRecvd == SOCKET_ERROR)
    {
      cerr << "ERROR in recvfrom()\n";
      closesocket(hSocket); WSACleanup(); return 1; 
    }
    MsgCount++;
    cout << "\n " << MsgCount << ": received: " << buffer; cout.flush();
    // (b) Process input  
    _strupr(buffer);
    // (c) Sent result to client
    nBytesSent = sendto (
           hSocket,
           buffer,
           strlen(buffer) + 1,
           NO_FLAGS_SET,
           (LPSOCKADDR) &ClientSockAddr, // holds client addr: IP, port
           sizeof(ClientSockAddr)
                        );
   if (nBytesSent != (int)strlen(buffer) + 1)
   {
     cout << "\n  Problem with sendto(). Connection terminated.\n";
     closesocket (hSocket); WSACleanup(); return 1;
   }
  } // while end
}
