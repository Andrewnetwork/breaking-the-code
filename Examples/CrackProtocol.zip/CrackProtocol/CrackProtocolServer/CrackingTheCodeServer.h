// CrackingTheCodeServer.h
// Andrew Ribeiro
// April 13, 2011

#pragma once 

#include <Windows.h>
#include <string> 
#include <map>

#include "..\GlobalHeaders\SimpleSocketsLibrary\SimpleServerSocket.h"
#include "CodeCrackingState.h"

using namespace AndrewRibeiro; 
using namespace std; 

class CrackingTheCodeServer 
{
public:
	void start();
	void stop();
	CrackingTheCodeServer();

private:
	string port; 
	map<string,string> getConfigurationVariables();
	friend DWORD WINAPI listenForClientsClients( LPVOID arg );
	SimpleServerSocket serverSocket;
	CodeCrackingState * serverState;
	
	bool isRunning;
};