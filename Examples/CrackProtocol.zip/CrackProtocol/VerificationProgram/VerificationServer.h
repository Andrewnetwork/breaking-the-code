// verificationServer.h
// Andrew Ribeiro 
// April 10, 2011

#pragma once 

#include <string>
#include <Windows.h>

using namespace std;

typedef bool (*VerificationPredicate)(string);

class VerificationServer
{
public:
	VerificationServer( string port );
	void start(); 
	void setVerificationFunction( VerificationPredicate verificationFunction);

private:
	string serverPort;
	VerificationPredicate verificationFunction;

};