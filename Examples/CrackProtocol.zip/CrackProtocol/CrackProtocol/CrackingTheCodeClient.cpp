// CrackingTheCodeClient.cpp
// Andrew Ribeiro
// April 13, 2011

#include <map>
#include <string>
#include <fstream>

#include "..\GlobalHeaders\SimpleSocketsLibrary\SimpleClientSocket.h"
#include "..\GlobalHeaders\SimpleSocketsLibrary\SimpleSocket.h"
#include "..\GlobalHeaders\SimpleSocketsLibrary\SocketCommunicator.h"

#include "Permutation.h"


#include "CrackProtocolClient.h"

#include "CrackingTheCodeClient.h"


using namespace AndrewRibeiro; 
using namespace std; 

void PushStringOntoBuffer(char *str);

// ## START Utility Functions ##
SOCKET connectToServer( string serverIP, string serverPort )
{
	SimpleClientSocket clientSock;

	return clientSock.connectToServer(serverIP,serverPort);
}

map<string,string> getConfigurationVariables()
{
	map<string,string> configVars;

	ifstream configFile("clientConfig.txt",ios::in);

	string line;
	int indexOfFirstSpace;

	while( !configFile.eof() )
	{
		getline( configFile,line,'\n');

		indexOfFirstSpace = line.find_first_of(' ');

		if( indexOfFirstSpace != string::npos )
		{

			configVars.insert( pair< string, string >( line.substr(0,indexOfFirstSpace ), line.substr(indexOfFirstSpace+1, line.size() - indexOfFirstSpace ) ) ); 
		}
	}

	return configVars;
}



// ## START Threading Functions/Methods ##

DWORD WINAPI crackCodeThread( LPVOID arg )
{
	CodeCrackingThreadArgs * args =  ( CodeCrackingThreadArgs *  ) arg ;

	SOCKET serverConnection = NULL;

	do
	{
		serverConnection = connectToServer(args->serverIP,args->serverPort);

	}while( serverConnection == NULL );

	CrackProtocolClient serverInterface( serverConnection);
	
	while( !*args->exitFlag)
	{
		bool codeCracked = false;

		SOCKET serverConn = NULL;
		
		SimpleClientSocket * serverSock = new SimpleClientSocket ;

		do
		{
			serverConn = serverSock->connectToServer("127.0.0.1",args->verificationPort);
		}
		while( serverConn == NULL );
		
		SocketCommunicator * verificationCom = new SocketCommunicator( serverConn );

		do
		{
			pair<vector<unsigned char>, vector<unsigned char> > range = serverInterface.getRange();
		
			Permutation perm(&(args->alphabet),args->alphaSize);

			perm.setRange( &range );

			
			while( !perm.haveCompletedRange() && !codeCracked && !*args->exitFlag)
			{
				verificationCom->write( perm.getPemutationString() );
				
				if( verificationCom->read() == "1" )
				{
					// This permutation cracked the code.
				
					serverInterface.rangeComplete ( perm.getPemutationString() );

					codeCracked = true;

				}

				++perm;
			}

			if( !codeCracked )
			{
				serverInterface.rangeComplete ( "" );
			}
	
		}while( !codeCracked && !*args->exitFlag );
	}

	delete args->exitFlag;
	delete args;
	
	return 0;
}

HANDLE CrackingTheCodeClient::startNewCodeCrackingThread(bool * exitFlag)
{
	SOCKET serverCon = connectToServer(serverIP,serverPort);

	CodeCrackingThreadArgs * threadArgs = new CodeCrackingThreadArgs( serverIP, serverPort, exitFlag, verificationPort, alphabet, alphabetSize );

	HANDLE hThread = CreateThread( 
						NULL,                   // default security attributes
						0,                      // use default stack size  
						crackCodeThread,       // thread function name
						threadArgs,          // argument to thread function 
						0,                      // use default creation flags 
						NULL);   // returns the thread identifier 

	return hThread;
}

// ## END Threading methods ##

// ## START Use Case Methods ##
void CrackingTheCodeClient::crackCode()
{
	// Get the verification archive.
	string promptString;
	SOCKET serverCon = connectToServer(serverIP,serverPort);

	if( serverCon != NULL )
	{
		CrackProtocolClient serverInterface( serverCon );

		serverInterface.getVerificationArchive();

		startVerificationServer();
	
		// Find out how many CPU's the client has and utilize them all.
		SYSTEM_INFO sysinfo;
		GetSystemInfo( &sysinfo );
		unsigned int nCPU = sysinfo.dwNumberOfProcessors;

		// For each CPU assign a thread.
		for( int i = 0; i < nCPU; i++)
		{
			serverCon = connectToServer(serverIP,serverPort);

			if( serverCon != NULL )
			{
				bool * pFlag = new bool;
				*pFlag = false;

				startNewCodeCrackingThread(  pFlag );
			}
			else
			{
				promptString = "Fatal Error: Could not connect to server.";
				PushStringOntoBuffer( (char *)promptString.c_str() );
			}
		}

		promptString = "Code is being cracked.";
		PushStringOntoBuffer( (char *)promptString.c_str() );
	}
	else
	{
		promptString = "Fatal Error: Could not connect to server.";
		PushStringOntoBuffer( (char *)promptString.c_str() );
	}
}

void CrackingTheCodeClient::startProcess(string processName, string email, string verificationArchivePath)
{
	string promptString;
	SOCKET serverCon = connectToServer( serverIP, serverPort );

	if( serverCon != NULL )
	{
		CrackProtocolClient serverInterface( serverCon );
		
		promptString = "Starting code cracking process.";
		PushStringOntoBuffer( (char *)promptString.c_str() );

		if( serverInterface.getProcessStatus() )
		{
			promptString = "Error: A process is already executing. You cannot start a new one until it finishes.";
			PushStringOntoBuffer( (char *)promptString.c_str() );
		}
		else
		{
			serverInterface.startProcess( processName, email, verificationArchivePath );
		}
	}
	else
	{
		promptString = "Fatal Error: Could not connect to server.";
		PushStringOntoBuffer( (char *)promptString.c_str() );
	}
}

void CrackingTheCodeClient::displayInfo()
{
	string promptString;
	SOCKET serverCon = connectToServer( serverIP, serverPort );

	if( serverCon != NULL )
	{
		CrackProtocolClient serverInterface( serverCon );
		
		promptString = "Retrieving process information.";
		PushStringOntoBuffer( (char *)promptString.c_str() );

		PushStringOntoBuffer( (char *)serverInterface.requestInformation().c_str() );
	}
	else
	{
		promptString = "Fatal Error: Could not connect to server.";
		PushStringOntoBuffer( (char *)promptString.c_str() );
	}
}

void CrackingTheCodeClient::stopCrackingCode()
{
	PushStringOntoBuffer( "Code cracking stoping." );

	for(int i = 0; i < codeCrackingExitFlags.size(); i++)
	{
		*codeCrackingExitFlags[i] = true;
	}

	TerminateThread( this->hVerificationServer , 0 );
}
// ## END Use Case Methods ##


CrackingTheCodeClient::CrackingTheCodeClient()
{
	map<string,string>  configVars = getConfigurationVariables();

	serverIP         = configVars["Server_IP"]; 
	serverPort       = configVars["Server_Port"]; 
	verificationPort = configVars["Verification_Port"]; 

	string alphaStr  = configVars["Alphabet_Pairs"]; 

	for( int i = 0; i+2 < alphaStr.size(); i++)
	{
		alphabet.push_back( alphaStr[i]);
		alphabet.push_back( alphaStr[i+2] );
	}

	// Calculate size of alphabet.
	alphabetSize = 0;

	for( int i = 0; i < alphabet.size(); i = i + 2 )
	{
		alphabetSize += ( alphabet[i+1] + 1 ) - alphabet[i];
	}

	// ## Initializiations ##

	hVerificationServer = NULL;
}


bool CrackingTheCodeClient::startVerificationServer()
{
	if( hVerificationServer == NULL )
	{
		STARTUPINFO         startUpInfo;
		PROCESS_INFORMATION procInfo;
		BOOL                success;
		char                appName[256];
		DWORD               processExitCode; 
		LPDWORD			    ptrProccessExitCode = &processExitCode; 

 
		strcpy (appName, "VerificationFolder\\VerificationProgram.exe\0" );

		// 2. Retrieve the STARTUPINFOR structure for current process
		GetStartupInfo(&startUpInfo);

		// Port
		string args = "VerificationProgram.exe "+verificationPort;

		// 3. Create the child process
		success = CreateProcess(
						appName, // or NULL    // app. name
						(LPSTR)args.c_str(),    // c:\ ... // command line
						NULL,   // security
						NULL,   // thread security
						FALSE,  // do not inherit handles of parent process
						DETACHED_PROCESS , // various constants CREATE_NO_WINDOW
						NULL,      // points to array of string containing environment variables
						NULL,      // Starting drive and directory for the process
						&startUpInfo, // appearance ifno
						&procInfo     // return info for process
								);

		hVerificationServer = procInfo.hProcess;

		return success;
	}
	else
	{
		return true;
	}

}