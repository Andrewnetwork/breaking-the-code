// QkListboxCtrl.cpp
#include "QkListboxCtrl.h"


CQkListboxCtrl::CQkListboxCtrl()
{
  hListboxWnd = NULL;
}

CQkListboxCtrl::~CQkListboxCtrl()
{
  if (hFont != NULL)
    DeleteObject (hFont);
  Destroy();
}

void CQkListboxCtrl::Create (HWND hWnd, UINT id, CPoint TopLeftPosition, int Width, int Height)
{
  // Step 1. Can only create it once
  if (hListboxWnd != NULL)
  {
    SetWindowText (hWnd,"Already created");
    Sleep (250);
    return;    // Already created.
  }
  hParent = hWnd;
  mID = id;

  // Step 2.  Set member properties
  mTopLeftPosition = TopLeftPosition;
  mWidth           = Width;
  mHeight          = Height;

  // Step 3. Create the window

  hListboxWnd = CreateWindowEx 
    (
    WS_EX_CLIENTEDGE,
    TEXT("listbox"),
    NULL,
    WS_CHILD|WS_BORDER|WS_VSCROLL|LBS_NOTIFY,
    mTopLeftPosition.x,
    mTopLeftPosition.y,
    mWidth,
    mHeight,
    hWnd,
    (HMENU)mID,
    (HINSTANCE)GetWindowLong (hWnd, GWL_HINSTANCE),
    NULL
    );
    hFont = (HFONT)GetStockObject (ANSI_FIXED_FONT);
    SendMessage (hListboxWnd,WM_SETFONT, (WPARAM)hFont, 0);
}

void CQkListboxCtrl::Destroy ()
{ 
  ShowWindow   (hListboxWnd,SW_HIDE);
  DeleteObject (hListboxWnd);
  hListboxWnd  = NULL;
}

int CQkListboxCtrl::GetSize ()
{
  return SendMessage (hListboxWnd, LB_GETCOUNT, 0, 0);
}

void CQkListboxCtrl::Show ()
{ 
  ShowWindow (hListboxWnd, SW_SHOW);
}

void CQkListboxCtrl::Hide ()
{ 
  ShowWindow (hListboxWnd, SW_HIDE);
}

void CQkListboxCtrl::Clear ()
{
  SendMessage (hListboxWnd, LB_RESETCONTENT, 0,0);
}

void CQkListboxCtrl::StrAdd (CString s)
{
  int idx;
  idx = SendMessage (hListboxWnd, LB_ADDSTRING, 0,(LPARAM)(LPCTSTR)s);
  SendMessage (hListboxWnd, LB_SETTOPINDEX, (WPARAM)idx, 0);
}

void CQkListboxCtrl::StrInsertAt (CString s, int idx)
{
  if (idx >= GetSize())
    idx = -1;
  SendMessage (hListboxWnd, LB_INSERTSTRING, (WPARAM)idx, (LPARAM)(LPCTSTR)s);
}

void CQkListboxCtrl::StrDelSel()
{
  int idx;
  idx = SendMessage (hListboxWnd, LB_GETCURSEL, 0, 0);
  if (idx == LB_ERR) return;
  SendMessage (hListboxWnd, LB_DELETESTRING, (WPARAM)idx, 0);
}

void CQkListboxCtrl::StrDelAt(int idx)
{
  SendMessage (hListboxWnd, LB_DELETESTRING, (WPARAM)idx, 0);
}

CString CQkListboxCtrl::StrGetSel()
{
  CString s;
  int idx;
  idx = SendMessage (hListboxWnd, LB_GETCURSEL, 0, 0);
  if (idx == LB_ERR)
    return "";
  else
    SendMessage (hListboxWnd, LB_GETTEXT, (WPARAM)idx, (LPARAM)(LPCTSTR)s);
  return s;
}

CString CQkListboxCtrl::StrGetAt(int idx)
{
  CString s;
  SendMessage (hListboxWnd, LB_GETTEXT, (WPARAM)idx, (LPARAM)(LPCTSTR)s);
  return s;
}

int CQkListboxCtrl::StrSelGetIndex()
{
  int idx;
  idx = SendMessage (hListboxWnd, LB_GETCURSEL, 0,0);
  return idx;
}

HWND CQkListboxCtrl::GetHandle()
{
  return hListboxWnd;
}

UINT CQkListboxCtrl::GetObjectID()
{
  return mID;
}

void CQkListboxCtrl::StrAdd(char c[])
{
  int idx;
  idx = SendMessage (hListboxWnd, LB_ADDSTRING, 0,(LPARAM)c);
  SendMessage (hListboxWnd, LB_SETTOPINDEX, (WPARAM)idx, 0);
}
