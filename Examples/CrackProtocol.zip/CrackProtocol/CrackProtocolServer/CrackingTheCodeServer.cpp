// CrackingTheCodeServer.cpp
// Andrew Ribeiro
// April 13, 2011

#include <Windows.h>
#include <string> 
#include <vector>
#include <map>
#include <fstream>
#include <list>

#include "..\GlobalHeaders\SimpleSocketsLibrary\SimpleServerSocket.h"
#include "..\GlobalHeaders\SimpleSocketsLibrary\SimpleSocket.h"
#include "..\GlobalHeaders\SimpleSocketsLibrary\SocketCommunicator.h"


#include "CrackProtocolServer.h"
#include "CodeCrackingState.h"
#include "CrackingTheCodeServer.h"


using namespace AndrewRibeiro; 
using namespace std; 

void PushStringOntoBuffer(char *str);

DWORD WINAPI handleClient( LPVOID arg )
{
	SOCKET clientConnection                 = ( SOCKET ) ( ( void ** ) arg )[0];
	CodeCrackingState * globalState         = ( CodeCrackingState * ) ( (void ** ) arg )[1];

	CrackProtocolServer clientInterface( clientConnection, globalState );

	clientInterface.processRequests();

	return 1;
}

DWORD WINAPI listenForClientsClients( LPVOID arg )
{
	CrackingTheCodeServer * server = ( CrackingTheCodeServer * ) arg;
	bool clientConnectionError     = false;
	string promptString;
	list< HANDLE > clientThreads;

	// Connect to client, and store socket/connection in 'clientConnection'
	do
	{
		// # Connecting the the server 'serverIP', on port 'serverPort'
		SOCKET clientConnection  = server->serverSocket.listenForConnection();

		if( clientConnection == NULL )
		{
			// Unable to connect.
			clientConnectionError = true;
		}
		else
		{
			// Connected to the server. 
			clientConnectionError = false; 

			void * threadArgsArray[2] = { (void * )clientConnection , server->serverState};
	
			clientThreads.push_back( CreateThread( 
            NULL,                   // default security attributes
            0,                      // use default stack size  
            handleClient,       // thread function name
            threadArgsArray,          // argument to thread function 
            0,                      // use default creation flags 
            NULL) );   // returns the thread identifier 


			promptString = "Client connected.";
			PushStringOntoBuffer( (char *)promptString.c_str() );
		}

	}while( !clientConnectionError && server->isRunning );

	// Terminate all client threads.
	for( list<HANDLE>::iterator i = clientThreads.begin(); i != clientThreads.end(); i++ )
	{
		TerminateThread( *i , 0 );
	}

	return 1;
}

map<string,string> CrackingTheCodeServer::getConfigurationVariables()
{
	map<string,string> configVars;

	ifstream configFile("serverConfig.txt",ios::in);

	string line;
	int indexOfFirstSpace;

	while( !configFile.eof() )
	{
		getline( configFile,line,'\n');

		indexOfFirstSpace = line.find_first_of(' ');

		if( indexOfFirstSpace != string::npos )
		{
			configVars.insert( pair< string, string >( line.substr(0,indexOfFirstSpace ), line.substr(indexOfFirstSpace+1, line.size() - indexOfFirstSpace ) ) ); 
		}
	}

	return configVars;
}


CrackingTheCodeServer::CrackingTheCodeServer()
{
	map<string,string>  configVars = getConfigurationVariables();
	port             = configVars["Server_Port"];
	isRunning = false; 

}

void CrackingTheCodeServer::start()
{
	// If the server is not started.
	if( !isRunning)
	{
		isRunning = true;

		serverState      = new CodeCrackingState();

		string promptString;

		if (serverSocket.bindToPort( port ) )
		{
			promptString = "Waiting for incoming connections on port "+port+".";
			PushStringOntoBuffer( (char *)promptString.c_str() );

			CreateThread( 
				NULL,                   // default security attributes
				0,                      // use default stack size  
				listenForClientsClients,       // thread function name
				this,          // argument to thread function 
				0,                      // use default creation flags 
				NULL);   // returns the thread identifier 
		}
		else
		{
			promptString = "Could not bind to port "+port+".";
			PushStringOntoBuffer( (char *)promptString.c_str() );
		}
	}
}

void CrackingTheCodeServer::stop()
{
	// If the server is not stoped.
	if( isRunning )
	{
		isRunning = false;

		delete serverState;

		this->serverSocket.unbind();
	}
}

