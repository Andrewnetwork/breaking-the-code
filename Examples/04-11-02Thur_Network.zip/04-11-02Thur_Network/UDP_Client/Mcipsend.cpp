//******************************************
// Original program by Marshall Brain
// Extensively modified by R. Jones for readability, etc
//******************************************
// Client:  mcipsend.cpp

#include <windows.h>
#include <iostream.h>
#include <winsock.h>

#define NO_FLAGS_SET  0
#define PORT          (u_short)44966

INT main(VOID)
{
  WSADATA       wsaData;
  SOCKET        hSocket;     // handle to socket
  SOCKADDR_IN   SockAddr;    // Holds address of target machine, port also 
  char          buffer[256]; // holds msg to be sent

  strcpy (buffer,"Happy birthday");

  // 1. Initialize WSA: Window Socket A'PI 
  int   status;
  status = WSAStartup(
              MAKEWORD(1, 1),// version
              &wsaData          // Info about winsocket implementation  
              );
  if (status != 0) cerr << "ERROR: WSAStartup unsuccessful\n";

  // 2. Create a socket. Essentially, it specifies protocol.
  hSocket = socket(         // Returns a 'handle' to the socket info
                AF_INET,    // Internet family
                SOCK_DGRAM, // SOCK_DGRAM = UDP,
                0           //
                );
  if (hSocket == INVALID_SOCKET) {cerr << "ERROR: socket unsuccessful\n"; return 1;}

  // 3. Initialize 'sockaddr_in' struct. Where messages sent. 
  SockAddr.sin_family       = AF_INET;
  SockAddr.sin_addr.s_addr  = htonl(INADDR_BROADCAST); // any machine
  SockAddr.sin_port         = htons(PORT);             // but this port

  // 4. Set Socket Options: permit broadcasting on the socket 
  int enable = 1;
  status = setsockopt(     // returns ZERO on success, SOCKET_ERROR for failure
              hSocket,          // handle to socket
              SOL_SOCKET,       // Related to OSI model. Highest (application) level
              SO_BROADCAST,     // SocketOption: Broadcast
              (char *) &enable, // Option value. Essentially, boolean option
              sizeof(enable)    // Option length.
              );
  if (status != 0) { cerr << "ERROR: setsockopt unsuccessful\n"; return 1;}
  
  // 5. Loop:  Send message and wait
  int  nBytesSent;
  while(1)
  {
    cout << "Sending..." << endl;
    nBytesSent = sendto(              // returns number bytes sent
                   hSocket,                // Handle to socket
                   buffer,                 // ptr to area holding message
                   strlen(buffer) + 1,     // length of message, include '\0'
                   NO_FLAGS_SET,           // flags that affect behavior of sendto()
                   (LPSOCKADDR) &SockAddr, // contains addr and prot # of target socket
                   sizeof(SockAddr)
                  );
    if (nBytesSent != (int)strlen(buffer) + 1)
    {
      cerr << "ERROR: sendto unsuccessful\n";
      status = closesocket (hSocket);
      if (status == SOCKET_ERROR) cerr << "ERROR: closesocket unsuccessful\n";
      status = WSACleanup();
      if (status == SOCKET_ERROR) cerr << "ERROR: WSACleanup unsuccessful\n";
      return 1;
    }
    Sleep(4800); // wait abit before sending next message
  } /* while */
}
