// QkListboxCtrl.h

// 1. This class gives the you (the programmer) the
//    ability to present a "scolling output window"
//    to the user where information is entered.

// 2. You don't have to know anything about this
//    class EXCEPT how to use the 5 methods.

#if !defined(_QKLISTBOXCTRL_H_)
#define _QKLISTBOXCTRL_H_

#include <afxwin.h>

class CQkListboxCtrl  
{
public:
	CQkListboxCtrl();
	virtual ~CQkListboxCtrl();

  void    Create      (HWND hWnd, UINT id, CPoint TopLeftPosition,
                        int Width, int Height);
  void    Destroy     ();
  int     GetSize     ();

  void    Show        ();
  void    Hide        ();
  void    Clear       ();

	void    StrAdd      (char c[]);
  void    StrAdd      (CString s);
  void    StrInsertAt (CString s, int idx);
  
  void    StrDelSel   ();
  void    StrDelAt    (int idx);
  CString StrGetSel   ();
  CString StrGetAt    (int idx);

  int     StrSelGetIndex ();

  HWND    GetHandle ();
  UINT    GetObjectID();

private:
  CPoint  mTopLeftPosition;
  int     mWidth;
  int     mHeight;
  HFONT   hFont;

  HWND    hListboxWnd;
  HWND    hParent; // Used to give focus back to parent window
  UINT    mID;
};

#endif
