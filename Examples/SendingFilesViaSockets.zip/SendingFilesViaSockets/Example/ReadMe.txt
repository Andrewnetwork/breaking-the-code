ReadMe.txt
Andrew Ribeiro
February 23, 2011

Note: This is a prototype, work still needs to be done to make it error safe, etc. 

This example works on the local host only. 

Running Instructions:

1.) Place the server and client in two seperate directories. 
2.) Place "zipToSend.zip" in the same directory as the server. 
3.) Start the server.
4.) Start the client. 
5.) On the server, type in the ziped directory file name: zipToSend.zip
6.) The server will print EOF file sent, meaning the file has been sent.
7.) Look in the directory of the client program and you will find zipToSend.zip which was sent by the server. 