#include <iostream>
#include <WinSock.h>
#include <string>
#include <mysql.h>
#include <vector>
#include <time.h>
#include <cstring>
#include <sstream>
#include "xmlwriter.h"
#include "SQL_XML.h"

using namespace std;
using namespace xmlw;

void main()
{
	SQL_XML run;
	MYSQL* connection = mysql_init(NULL);
	run.check_connection(connection);

	cout << " Enter user name and Email : "<<endl;
	string name, email, code;

	getline(cin,name);	getline(cin,email);
	run.starting_info( connection, name, email);
	system("pause");

	cout << " Enter the code " <<endl;
	getline ( cin, code );
	run.ending_info ( connection, code ) ;
	system("pause");

	run.SQL_Query( connection);
	system("pause");

	string x = run.read_xml();
	cout << x;
	system("pause");

	cout << run.parse_xml(x);
	system("pause");

}