// verificationProgram.cpp
// OUTDATED
// Andrew Ribeiro 
// April 10, 2011

#include <string>
#include <Windows.h>

#include "..\GlobalHeaders\SimpleSocketsLibrary\SimpleServerSocket.h"
#include "..\GlobalHeaders\SimpleSocketsLibrary\SimpleSocket.h"
#include "..\GlobalHeaders\SimpleSocketsLibrary\SocketCommunicator.h"

#include "VerificationServer.h"

using namespace std;
using namespace AndrewRibeiro;

DWORD WINAPI handleClient( LPVOID arg );

bool basicVerificationFunction( string permutation );

bool passwordProtectedZipVerificationFunction( string permutation );

void main( int argc, char * argv[] )
{
	string serverPort( argv[1] );
	VerificationServer verificationServer( serverPort );
	
	verificationServer.setVerificationFunction( passwordProtectedZipVerificationFunction );

	verificationServer.start();
}

bool basicVerificationFunction( string permutation )
{
	if( permutation == "aaa" )
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool passwordProtectedZipVerificationFunction( string permutation )
{
	STARTUPINFO         startUpInfo;
	PROCESS_INFORMATION procInfo;
	BOOL                success;
	char                appName[256];
	DWORD               processExitCode; 
	LPDWORD			  ptrProccessExitCode = &processExitCode; 


 
	strcpy (appName, "VerificationFolder\\7zip\\7z.exe\0" );

	// 2. Retrieve the STARTUPINFOR structure for current process
	GetStartupInfo(&startUpInfo);

	string args = "7z x VerificationFolder\\PasswordProtectedArchive.zip -y -p"+permutation;

	// 3. Create the child process
	success = CreateProcess(
					appName, // or NULL    // app. name
					(LPSTR)args.c_str(),    // c:\ ... // command line
					NULL,   // security
					NULL,   // thread security
					FALSE,  // do not inherit handles of parent process
					CREATE_NO_WINDOW , // various constants CREATE_NO_WINDOW
					NULL,      // points to array of string containing environment variables
					NULL,      // Starting drive and directory for the process
					&startUpInfo, // appearance ifno
					&procInfo     // return info for process
							);


	WaitForSingleObject( procInfo.hProcess, INFINITE );

	GetExitCodeProcess( procInfo.hProcess, ptrProccessExitCode );

	if( *ptrProccessExitCode == 0 )
	{
		return true;
	}
	else
	{
		return false;
	}
}