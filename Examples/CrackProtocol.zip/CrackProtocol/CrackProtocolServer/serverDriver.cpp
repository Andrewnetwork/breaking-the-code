// serverDriver.cpp
// Andrew Ribeiro 
// April 10, 2010

#include "CrackingTheCodeServer.h"

void main()
{
	CrackingTheCodeServer a;

	a.start();

	system("pause");
}

