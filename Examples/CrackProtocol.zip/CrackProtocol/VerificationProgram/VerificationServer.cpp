// verificationServer.cpp
// Andrew Ribeiro 
// April 10, 2011

#include "VerificationServer.h"
#include "..\GlobalHeaders\SimpleSocketsLibrary\SimpleServerSocket.h"
#include "..\GlobalHeaders\SimpleSocketsLibrary\SocketCommunicator.h"

#include <string>
#include <vector>

using namespace std;
using namespace AndrewRibeiro;



DWORD WINAPI handleClient( LPVOID arg )
{
	SOCKET clientConnection                     = ( SOCKET ) ( ( void ** ) arg )[0];
	VerificationPredicate verificationFunction  = ( VerificationPredicate ) ( ( ( void ** ) arg )[1] );
	SocketCommunicator *  clientCom             = new SocketCommunicator( clientConnection ); 
	bool clientCommunicationError               = false;
	string permutation;

	// # Start conversation loop.
	
	do
	{
		permutation = clientCom->read();

		if( permutation.length() > 0 )
		{
			if( verificationFunction( permutation ) )
			{
				clientCom->write( "1" );
			}
			else
			{
				clientCom->write( "0" );
			}
		}
		else
		{
			cout<<"ERROR: Communication ended abruptly with client."<<endl;
			clientCommunicationError  = true;
		}

	}while( !clientCommunicationError ); 

	return 1;
}


void VerificationServer::setVerificationFunction(VerificationPredicate verificationFunction)
{
	this->verificationFunction = verificationFunction;
}

VerificationServer::VerificationServer( string port )
{
	serverPort = port;
}


void VerificationServer::start()
{
	SimpleServerSocket    serverSock;
	bool    clientConnectionError = false;

	serverSock.bindToPort( serverPort );

		do
	{
		// # Connecting the the server 'serverIP', on port 'serverPort'
		SOCKET                clientConnection  = serverSock.listenForConnection();

		if( clientConnection == NULL )
		{
			// Unable to connect.
			clientConnectionError = true;
			cout<<"Could not connect to client on port '"<<serverPort<<"'."<<endl;
		}
		else
		{
			// Connected to the server. 
			clientConnectionError = false;

			void * args[] = { (void *)clientConnection, verificationFunction };

			CreateThread( 
            NULL,                   // default security attributes
            0,                      // use default stack size  
            handleClient,       // thread function name
            args,          // argument to thread function 
            0,                      // use default creation flags 
            NULL);   // returns the thread identifier 


			cout<<"Server connected to client on port '"<<serverPort<<"'."<<endl; 

		}


	}while( !clientConnectionError );
}