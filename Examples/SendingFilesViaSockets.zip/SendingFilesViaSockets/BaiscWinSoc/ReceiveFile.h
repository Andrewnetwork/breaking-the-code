#pragma once
#include <Windows.h>
#include <string>

using namespace std;

class ReceiveFile
{
public:
	ReceiveFile( SOCKET activeConnection );
	string getFileWithName( );

private:
	SOCKET activeConnection; 
};