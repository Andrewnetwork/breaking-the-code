#include <vector> 
#include <iostream>
#include <string>
#include "Permutation.h"
using namespace std; 

// #Constructors 
Permutation::Permutation(unsigned int length, vector<char> * alphabet, unsigned int alphabetSize)
{
	counters.resize( length );
	this->alphabet = alphabet; 
	this->alphabetSize = alphabetSize;
}

// #Essentials
const Permutation & Permutation::operator++()
{
	for(int digitIndex = counters.size() - 1; digitIndex >= 0; digitIndex--)
	{
		if(counters[digitIndex] + 1 >= alphabetSize )
		{
			counters[digitIndex] = 0;
		}
		else
		{
			counters[digitIndex] += 1; 
			digitIndex = -1; // Done
		}
	}

	return *this;
}

string Permutation::getPemutationString()
{
	string outStr = "";

	for(int i = 0; i < counters.size(); i++ )
	{
		outStr+=characterAtPositionInAlphabet( alphabet, getCountersReference()[i]  );
	}

	return outStr;
}

// #Utility 
unsigned int Permutation::characterPositionInAlphabet( vector< char > * alphabet,  char ch )
{
	unsigned int position = 0;

	for( unsigned int i = 0; i < alphabetSize; i = i + 2 )
	{
		for( unsigned int charOnRange = (*alphabet)[i]; charOnRange <= (*alphabet)[i+1]; charOnRange++ )
		{
			if( charOnRange == ch )
			{
				return position; 
			}

			position++;
		}
	}
}

char Permutation::characterAtPositionInAlphabet( vector< char > *alphabet, unsigned int pos )
{
	unsigned int position = 0;

	for( unsigned int i = 0; i < alphabetSize; i = i + 2 )
	{
		for( unsigned int charOnRange = (*alphabet)[i]; charOnRange <= (*alphabet)[i+1]; charOnRange++ )
		{
			if( position == pos )
			{
				return charOnRange; 
			}

			position++;
		}
	}
}

void Permutation::initCounters( unsigned int value )
{
	for( int i = 0; i < counters.size(); i++)
	{
		counters[i] = value; 
	}
}

void Permutation::incrementCounters(unsigned int incrementAmt)
{
	if( incrementAmt != 0 )
	{
		unsigned long int remainder = incrementAmt; 

		int digitCount = 1;

		do
		{
			counters[counters.size() - digitCount ] = remainder % alphabetSize; 

			remainder = remainder / alphabetSize;

			digitCount++;

		}while(remainder > 0);

	}

}
// #Overloads

unsigned int & Permutation::operator[]( unsigned int index )
{
	return counters[index]; 
}

// #Friends 
ostream& operator<<(ostream& output, Permutation p) 
{
	output<<p.getPemutationString();
	
	return output;
}