// QkButton.cpp

#include "QkButton.h"

CQkButton::CQkButton()
{
  hButtonWnd = NULL;
  mID = 0;
}

CQkButton::~CQkButton()
{
}

void  CQkButton::Create (HWND hWnd, UINT id,
                         CPoint     xyPosition,
                         CString    Caption,
                         int Width, int Height)
{
  // Step 1. Can only create it once
  if (hButtonWnd != NULL)
  {
    SetWindowText (hWnd,"Already created");
    Sleep (250);
    return;    // Already created.
  }
  // Step 2.  Set member properties
  hParent   = hWnd;
  mID       = id;
  mPosition = xyPosition;
  mCaption  = Caption;
  mWidth    = Width;
  mHeight   = Height;
  mVisible  = FALSE;

  HDC hDC = GetDC(hWnd);
  // Step 3. If mHeight is zero,
  //         determine the height of a character.
  if (mHeight == 0)
  {
    TEXTMETRIC tm;
    GetTextMetrics (hDC,&tm);
    int BoxHeight = tm.tmHeight + tm.tmExternalLeading + 10;
    mHeight = BoxHeight;
  }
  // Step 4. If mWidth is zero,
  //         determine the width of the button.
  if (mWidth == 0)
  {
    CSize sz;
    GetTextExtentPoint32 (hDC, mCaption, mCaption.GetLength(), &sz);
    mWidth = sz.cx + 10;
  }
  
  // End step 3 & 4
  ReleaseDC(hWnd,hDC);

  // Step 6: Create the QkButton
  hButtonWnd = CreateWindow 
    (
    TEXT("button"),
    mCaption,
    WS_CHILD|BS_DEFPUSHBUTTON, // styles
    mPosition.x,               // left edge
    mPosition.y,               // top edge
    mWidth,                    // width
    mHeight,                   // height
    hWnd,                      // parent window
    (HMENU)mID, // window ID, 
    (HINSTANCE)GetWindowLong (hWnd, GWL_HINSTANCE), 
    NULL  // creation parameters
    );
}
void  CQkButton::Show   ()
{
  ShowWindow (hButtonWnd, SW_SHOW);
  mVisible = TRUE;
}
void  CQkButton::Hide   ()
{
  ShowWindow (hButtonWnd, SW_HIDE);
  mVisible = FALSE;
}
UINT  CQkButton::GetButtonID ()
{
  return mID;
}
