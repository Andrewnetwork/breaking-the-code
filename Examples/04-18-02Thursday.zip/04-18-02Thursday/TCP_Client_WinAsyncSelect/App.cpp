// App.cpp: implementation of the CApp class.

#include "App.h"


CApp::CApp()
{

}

CApp::~CApp()
{

}

void CApp::Do()
{

}
