#include <iostream>
#include "..\SimpleSocketsLibrary\SimpleClientSocket.h"
#include "..\SimpleSocketsLibrary\SocketCommunicator.h"

using namespace std; 
using namespace AndrewRibeiro;

void main()
{
	SimpleClientSocket clientSock;
	SocketCommunicator * clientToServerCom;

	SOCKET server = clientSock.connectToServer("127.0.0.1","8203");
	
	clientToServerCom = new SocketCommunicator( server );

	while( true )
	{
		string inMessage; 

		// Get message. 
		inMessage = clientToServerCom->read();
		
		if( inMessage.length() > 0 )
		{
			cout<<"From server: "<<inMessage<<endl;
		}
		else
		{
			cout<<"Server ended communication with you. Ouch."<<endl;
			break;
		}

	}

	system("pause");
}