#include <iostream>
#include <fstream>
using namespace std;

const unsigned int bufferSize = 500; 

void main()
{
	char strBuffer[ bufferSize ]; 

	ifstream inputFile( "TestProgramToTransmit.exe", ios::binary);
	ofstream outputFile( "Out.exe" , ios::binary);

	while( !inputFile.eof() )
	{
		inputFile.read( strBuffer, bufferSize );

		outputFile.write( strBuffer, bufferSize );
	}



	
	inputFile.close();
	outputFile.close();


	system("pause");
}