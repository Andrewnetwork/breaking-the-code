//******************************************
// UDP_2_Client
//                Sends: string to server 
//   Receives in return: captialized string
//******************************************
#include <windows.h>
#include <iostream.h>
#include <winsock.h>
#include <conio.h>   // for getch()

#define NO_FLAGS_SET  0
#define PORT          (u_short)44966
#define MAXBUFLEN     256

int main(VOID)
{
  WSADATA       wsaData;
  SOCKET        hSocket;     // handle to socket
  SOCKADDR_IN   SockAddr;    // Holds IP address & port # of server 

  // 1. Initialize WSA: Window Socket A'PI 
  int   status;
  status = WSAStartup (
             MAKEWORD(1, 1),// version
             &wsaData       // Info about winsocket implementation  
                      );
  if (status != 0) {cerr << "ERROR in WSAStartup()\n"; return 1;} 

  // 2. Create a socket. Specifies protocol: UDP or TCP
  hSocket = socket (         // Returns a 'handle' to the socket info
             AF_INET,    // Internet family
             SOCK_DGRAM, // SOCK_DGRAM = UDP,
             0           //
                   );
  if (hSocket == INVALID_SOCKET) {cerr << "ERROR: socket unsuccessful\n"; return 1;}
  cout << "\nUDP_2_ClientMod: Sends a string x times. Server will capitalize.";
  int nTimes;
  cout << "\n  How many times to send string ? "; cin >> nTimes;
  int waitMilSec;
  cout << "  Milliseconds between each msg sent ? "; cin >> waitMilSec;

  // 3. Initialize 'sockaddr_in' struct with server info 
  //    3.a) Get IP address of server
  char Server_IP_Addr[40];
  cout << "\n  Enter IP addr (0 = local host) of server ? ";
  cin.getline (Server_IP_Addr,40); // eat cr
  cin.getline (Server_IP_Addr,40);
  if ( strcmp (Server_IP_Addr,"0") == 0) strcpy (Server_IP_Addr,"127.0.0.1");
  //    3.b) Get port # for service
  u_short  port;
  cout << "  Enter port # (44966?)for server ? "; cin >> port;
  //    3.c) Assign address and port -
  SockAddr.sin_family      = AF_INET;
  SockAddr.sin_addr.s_addr = inet_addr (Server_IP_Addr);
  SockAddr.sin_port        = htons(port);

  // 4. (a) Send message and (b) receive result
  char buffer[MAXBUFLEN], StrEntered[MAXBUFLEN];
  int  nBytesSent;
  int  nBytesRecvd;
  cout << "Enter msg to send ? ";
  cin.getline(StrEntered,MAXBUFLEN); // eat cr 
  cin.getline(StrEntered,MAXBUFLEN);

  for (int i = 0; i < nTimes; i++) // Loop for testing
  {
    // (a) Sending message
    strcpy (buffer,StrEntered);
    cout << "\nSending..." << buffer; cout.flush();
    nBytesSent = sendto (     // returns number bytes sent
            hSocket,                // Handle to socket
            buffer,                 // ptr to area holding message
            strlen(buffer) + 1,     // length of message, include '\0'
            NO_FLAGS_SET,           // flags that affect behavior of sendto()
            (LPSOCKADDR) &SockAddr, // Server IP and port #
            sizeof(SockAddr)
                        );
    if (nBytesSent != (int)strlen(buffer) + 1)
    { cerr << "ERROR: sendto unsuccessful\n";
      closesocket (hSocket); WSACleanup(); return 1;
    }

    // (b) Receive result
    nBytesRecvd = recvfrom (
            hSocket,
            buffer,       sizeof buffer,
            NO_FLAGS_SET,
            NULL,         NULL
                           );
    cout << "   Received: " << buffer; cout.flush();
    if ( waitMilSec > 0 ) Sleep(waitMilSec);
  } // for end
  closesocket(hSocket);
  WSACleanup();
  cout << "\n <Press any key to exit>";cout.flush(); getch();
  return 0;
}
