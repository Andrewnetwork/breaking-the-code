//***********************************
// Project: TCP_Server_SingleThread
// Project settings: Link tab: wsock32.lib
// Receives: a string. Returns:  the uppercase string
//***********************************
#include <windows.h>
#include <iostream>
#include <winsock.h>
using namespace std;

#define NO_FLAGS_SET    0
#define PORT            (u_short)44965
#define MAXBUFLEN       256

int main(VOID)
{
  WSADATA      wsaData;
  SOCKET       hServSocket;
  SOCKADDR_IN  serverSockAddr;
  int          addrLen = sizeof(SOCKADDR_IN);
  
  // 1. Initialize WSA, the Window Socket API
  int status;
  status = WSAStartup ( MAKEWORD(1, 1), &wsaData );
  if (status != 0) { cerr << "ERROR in WSAStartup\n"; return 1; }
  
  // 2. Create a socket
  hServSocket = socket (
                   AF_INET,
                   SOCK_STREAM, // that is, TCP not UDP
                   0
                         );
  if (hServSocket == INVALID_SOCKET)
  {
    cerr << "ERROR in socket create\n"; WSACleanup(); return 1 ;
  }
  
  // 3. Initialize server socket info 
  memset(&serverSockAddr, 0, sizeof(serverSockAddr));
  serverSockAddr.sin_family       = AF_INET;
  serverSockAddr.sin_addr.s_addr  = htonl(INADDR_ANY);
  serverSockAddr.sin_port         = htons(PORT);
  
  // 4. Bind the socket with the address
  status = bind (
             hServSocket, 
             (LPSOCKADDR) &serverSockAddr,
             sizeof(serverSockAddr))
                ;
  if (status == SOCKET_ERROR) { cerr << "ERROR in bind()\n"; return 1;}
  
  // 5. Listen for connections
  status = listen ( hServSocket, 1 );
  if (status == SOCKET_ERROR) { cerr << "ERROR in listen()\n"; return 1;}
  cout << "\nTCP Server (single threaded) listening on port " << PORT; cout.flush();
  
  SOCKET       hClientSocket;
  SOCKADDR_IN  clientSockAddr;
  
  while(1) // 6. Accept connection request when one received
  {
    char resp;
    cout << "\nDo you want to (wait to) accept another connection (y/n) ";
    cin >> resp;
    if ( toupper(resp) == 'N') break;
    cout << "Waiting . . ."; cout.flush();
    
    hClientSocket = accept ( 
                     hServSocket,
                     (LPSOCKADDR) &clientSockAddr,
                     &addrLen
                          );
    if (hClientSocket == INVALID_SOCKET) { cerr << "ERROR in accepting\n"; return 1; }
    cout << "\n  Accepted another client"; cout.flush();

    // - - - handle the new client - - - - - - 
    char    buffer[MAXBUFLEN];
    int     nBytesSent;
    int     nBytesRecvd;
    
    while(1) // 7. Conversation loop
    {
      // (a) Receive 
      nBytesRecvd = recv (
                      hClientSocket, // holds address of client 
                      buffer,       // message
                      MAXBUFLEN,    //
                      NO_FLAGS_SET
                         );
      if ((nBytesRecvd == 0) || (nBytesRecvd == SOCKET_ERROR))
      {
        cout << "\n  Connection terminated\n"; cout.flush();
        break;
      }
      cout << "\nMessage received: " << buffer; cout.flush();
      // (b) Process. Obviously, this could be much more involved
      _strupr(buffer);            // converts string to uppercase
      
      // (c) Send results back to client
      nBytesSent = send (
                    hClientSocket, // to address of client
                    buffer,       // results
                    strlen(buffer) + 1,
                    NO_FLAGS_SET
                        );
      if (nBytesSent != (int)strlen(buffer) + 1)
      {
        cout << "Connection terminated.\n"; cout.flush();
        break;
      }
    } // while end
    
    // 8. Terminate the connection with the client
    shutdown    ( hClientSocket, 2);
    closesocket ( hClientSocket );
    // - - - -  done with client - - - - - - 

  } // while end - accept connection
  // 9. Terminate
  shutdown    (hServSocket,2);
  closesocket (hServSocket);  
  return 0;
}
