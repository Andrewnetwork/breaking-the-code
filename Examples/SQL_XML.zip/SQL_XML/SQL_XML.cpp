#include "SQL_XML.h"
#include "xmlwriter.h"

using namespace std;
using namespace xmlw;

#include <iostream>
#include <string>
#include <vector>

/**				Information to connect to Database.		*/
const string host 	 = "173.201.88.97";			// Server Host
const string user	 = "breakingthecode";	    // User name
const string passwrd = "Csisfun1234";			// Password
const string db		 = "breakingthecode";		// Name of the database
const int port 		 = 3306;					// Port number

MYSQL* connection = mysql_init(NULL);

SQL_XML::SQL_XML()
{
	u_id = '0' ; p_id = '0';
	count1 =  0; count2 = 0;
}
void SQL_XML::check_connection	( MYSQL* connection )
{
	/*****************************************************************************
	*	This function will connect this program to remote Database. It is using  *
	*	mysql_real_connect (...) function and print appropriate message.		 *
	*	It is important to connect successfully to access any of mysql functions.*
	*****************************************************************************/
	
	if (mysql_real_connect(
							connection,					// MySQL obeject
							host.c_str(),				// Server Host
							user.c_str(),				// User name of your database
							passwrd.c_str(),			// Password of the database
							db.c_str(),					// Database name
							port,						// port number
							NULL,						// Unix socket  ( for us it is null )
							0)== NULL)
   {
      cout << "Error" << mysql_error(connection) << "\n";	// Printing an Error Message
	  check_connection(connection);
   }
   else 
   {
	   cout << "DBS is connected." <<endl;						// Printing connection messege.
   }
}

void SQL_XML::starting_info ( MYSQL* connection, string u_name, string u_email )
{
	/*******************************************************************************************
	*	This function would take user name, email and also store the starting time cracking	   *
	*	the code, and also store the process Id of cracking procedure.						   *
	*******************************************************************************************/
	stringstream ss;
	string id;
	++u_id;
	ss << u_id;
	ss >> id;

    time_t start;
	time ( &start );
	string starttime = ctime (&start);
	
	user_name.push_back ( u_name );							// Storing user name into vector
	user_id.push_back( id );						    	// Storing user id into vector
	user_email.push_back ( u_email );						// Storing user email into vector
	
	proccess_id.push_back(id);
	code.push_back("NULL");
	time_start.push_back(starttime.c_str());				// Storing current time into vector
	time_end.push_back("NULL");

	string user_tab = "user ( user_id, user_name, user_email )";
	string proc_tab = "proccess ( process_id, user_id, code, start_time, end_time )";
	string insert 	= "Insert into ";
	string values 	= "values ('";
	string syntax	= "','";
	string end_in	= "')";
	
	string insert_user = insert + user_tab + values + user_id[count1] + syntax + user_name[count1] +
						syntax + user_email[count1] + end_in;
	string insert_proc = insert + proc_tab + values + proccess_id[count1] + syntax + user_id[count1] +
						syntax + code[count1] + syntax + time_start[count1] +syntax + time_end[count1] + end_in;
	
	execute_command ( connection, insert_user);
	execute_command ( connection, insert_proc);
	
	++count1;
}

void SQL_XML::ending_info (	MYSQL* connection, string end_code )
{
	/*******************************************************************************************
	*	This function would take user ending code from user. It would also store iformation of *
	*	Process Id, code and time ending for the cracking the code procedure.				   *
	*******************************************************************************************/

	count1= count1-1;
		
	time_t end;											// Creating object of time class
	time ( &end );										// Gettting current time
	string endtime = ctime (&end);						// Storing time into a string 
	
	code[count1] = end_code;						// Storing code into a vector
	time_end[count1] = endtime.c_str() ;				// Storing ending time of proccess
	
	string insert_proc = " UPDATE proccess SET code ='" + code [count1] + "' , end_time ='" + time_end [count1] +"' WHERE process_id ='" + proccess_id[count1] + "' AND user_id ='" + user_id[count1]+ "' ";
	execute_command ( connection, insert_proc );

	++count1;
}

string SQL_XML::execute_command ( MYSQL* connection, string command )
{
	/******************************************************************************
	*	This function take MYSQL obeject and command ( string ) and perform the   *
	*	Query and also print the result if there is any out put.				  *
	*******************************************************************************/
	 
	if (mysql_query(
					connection,							// MySQL object
					command.c_str()						// SQL Command String
					) != 0)
   {
      cout << "ERROR" << endl << mysql_error(connection)  // Printing error message
			<< endl ;	
      return  "";
   }

   MYSQL_RES* result = mysql_store_result(connection);	//Storing the result into MYSQL_RES object
  
   if (result == NULL)
	   return ""; 
   else 
   {
	   string prnt="";
	   int rows = mysql_num_rows(result);					// Getting number of rows in result
	   int fields = mysql_num_fields(result);				// Getting number of fields in rows
	  
	   for (int i = 1; i <= rows; i++)
	   {
		  MYSQL_ROW row = mysql_fetch_row(result);			// Separating rows and storing into MYSQL_ROW object

		  for (int j = 0; j < fields; j++)
		  {
			 string field(row[j]);
			 
			 if (j > 0) 
			 {
				 prnt = prnt +  ",";
			 }
			prnt = prnt +  field ;							// adding the attribute
		  }
		  prnt = prnt + "\n";								// separating lines in output
	   }
	   mysql_free_result(result);							// releasing memory   
	   return prnt;
	} 
 				
}

void SQL_XML::SQL_Query( MYSQL* connection)
{
	string Query = "select `user`.`user_name` , `user`.`user_email` , `proccess`.`code` , `proccess`.`start_time` , `proccess`.`end_time` from user, proccess order by `proccess`.`user_id`";
														 // Making a SQL Query 

	string result = execute_command ( connection, Query ); 				// executing previously generated SQL commands
	
	make_xml(result);
}
void SQL_XML::make_xml ( string str )
{
	
	/*************************************************************************************
	*	This function will take information which was requested in Query and make an	 *
	*	XML for the resulting data.														 *
	**************************************************************************************/
	ofstream f("sample.xml");
	XmlStream xml(f);
	bool cond = true;
	string temp;
	vector < string > v;

	for ( int i = 0; i < str.size(); i++ )
	{
		temp = "";
		while ( i < str.size() && str[i] != ',' && str[i] != '\n')
		{
			temp =  temp + str[i] ;
			i++;
		}
		if ( temp != "")
			v.push_back(temp);
	}
	
	xml << prolog()										 // XML file declaration
		<< tag("Result"); 								// root tag
	for ( int i = 0; i < v.size(); i++ )
	{
		xml << tag ("Line") 						// child tag
			<< tag ("user_name")  << chardata() << v[i++]  << endtag ("user_name") 
			<< tag ("user_emaiL") << chardata() << v[i++] << endtag ("user_emaiL") 
			<< tag ("code") 	  << chardata() << v[i++] << endtag ("code")
			<< tag ("start_time") << chardata() <<v[i++] << endtag ("start_time")
			<< tag ("end_time")   << chardata() << v[i++] << endtag ("end_time")
			<<endtag("Line");
		i--;
	}

	xml << endtag("Result");
}
	
string SQL_XML::read_xml()
{
	ifstream ifile("sample.xml", ios::in);
	if (ifile.fail())
	{
		return " Failed to open input file. \n";		// Error message in case of file cannot open
	}
	else
	{	string temp ="";
		for( int i = 0; !ifile.eof(); i++)
		{
			temp.push_back(ifile.get());
		}
		return temp;
	}
	
}

string SQL_XML::parse_xml(string temp)
{
	string result;
	if ( temp.size() == 0 )
		cout << "Empty string " <<endl;
	else
	{
		for ( int i = 0; i < temp.size(); i++)
		{
			if (( temp[i] =='>')&&(temp[++i]!='<'))
			{
				do{
					result.push_back(temp[i]);
					++i;
					if ( i >= temp.size())
						break;
				}while ( temp[i]!='<');
				result.push_back(' ');
			}

		}
		return result;
	}
}

void SQL_XML::trial ( string str )
{
  string temp;
  vector < string >v;
  for ( int i = 0; i < str.size(); i++ )
  {
	  temp = "";
	  while ( i < str.size() && str[i] != ',' && str[i] != '\n')
	  {
		  temp =  temp + str[i] ;
		  i++;
	  }

	  if ( temp != "")
		  v.push_back(temp);
  }

  for ( int i = 0; i < v.size() ; i ++ )
  {
	  cout << v[i]<<endl;
  }
	system("pause");
}