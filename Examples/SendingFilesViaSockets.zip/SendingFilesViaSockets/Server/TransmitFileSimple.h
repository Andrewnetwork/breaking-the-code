// TransmitFile.h
// Andrew Ribeiro
// February 22, 2011

#pragma once
#include <Windows.h>
#include <string>

using namespace std;

class TransmitFileSimple
{
public:
	TransmitFileSimple( SOCKET activeConnection );
	bool sendFileWithName( string filePath );

private:
	SOCKET activeConnection; 
};