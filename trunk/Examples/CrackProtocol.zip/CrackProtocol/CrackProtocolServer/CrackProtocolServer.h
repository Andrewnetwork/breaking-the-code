// CrackProtocolServer.h
// Andrew Ribeiro
// April 10, 2011

#pragma once 

#include <Windows.h>
#include <string> 
#include <vector>

#include "..\GlobalHeaders\SimpleSocketsLibrary\SocketCommunicator.h"
#include "..\GlobalHeaders\CrackProtocolConstants.h"

#include "CodeCrackingState.h"


using namespace AndrewRibeiro; 
using namespace std; 



class CrackProtocolServer
{
public:

	CrackProtocolServer( SOCKET activeConnection , CodeCrackingState * globalState);

	bool processRequests();

private:
	SOCKET connection;
	SocketCommunicator * connectionCom;
	CodeCrackingState * gobalState;

	string getFileContents( string filePath );
	bool makeDirectory( string name, string bin );


	// Protocol Functions 

	bool recvRangeComplete(); 

	bool sendProcessStatus();

	void startProcess();

	void sendRange();

	void sendVerificationArchive();

	void sendInvalidOperationMessage(string errorMessage);

	// ## Database Related Methods ##
	bool addProcessRecordToDB( string name, string email );
	//void requestInformation();
};